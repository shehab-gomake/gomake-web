"use strict";
exports.id = 36;
exports.ids = [36];
exports.modules = {

/***/ 5604:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "aE": () => (/* reexport */ CustomersIcon),
  "tv": () => (/* reexport */ HomeIcon),
  "pA": () => (/* reexport */ ProductFloorIcon),
  "bp": () => (/* reexport */ ProductsIcon),
  "JM": () => (/* reexport */ ReportsIcon),
  "_6": () => (/* reexport */ SalesIcon),
  "x9": () => (/* reexport */ ShopingIcon),
  "$9": () => (/* reexport */ TabCloseIcon)
});

// UNUSED EXPORTS: SuppliersIcon

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/icons/home.tsx

const HomeIcon = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M5 10H7C9 10 10 9 10 7V5C10 3 9 2 7 2H5C3 2 2 3 2 5V7C2 9 3 10 5 10Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M17 10H19C21 10 22 9 22 7V5C22 3 21 2 19 2H17C15 2 14 3 14 5V7C14 9 15 10 17 10Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M17 22H19C21 22 22 21 22 19V17C22 15 21 14 19 14H17C15 14 14 15 14 17V19C14 21 15 22 17 22Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M5 22H7C9 22 10 21 10 19V17C10 15 9 14 7 14H5C3 14 2 15 2 17V19C2 21 3 22 5 22Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./src/icons/sales.tsx

const SalesIcon = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M10.11 11.1501H7.45999C6.82999 11.1501 6.32001 11.6601 6.32001 12.2901V17.4101H10.11V11.1501V11.1501Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M12.7613 6.6001H11.2412C10.6112 6.6001 10.1013 7.11011 10.1013 7.74011V17.4001H13.8913V7.74011C13.8913 7.11011 13.3913 6.6001 12.7613 6.6001Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M16.5481 12.8501H13.8981V17.4001H17.6881V13.9901C17.6781 13.3601 17.1681 12.8501 16.5481 12.8501Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./src/icons/shoping.tsx

const ShopingIcon = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M2 2H3.74001C4.82001 2 5.67 2.93 5.58 4L4.75 13.96C4.61 15.59 5.89999 16.99 7.53999 16.99H18.19C19.63 16.99 20.89 15.81 21 14.38L21.54 6.88C21.66 5.22 20.4 3.87 18.73 3.87H5.82001",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M16.25 22C16.9404 22 17.5 21.4404 17.5 20.75C17.5 20.0596 16.9404 19.5 16.25 19.5C15.5596 19.5 15 20.0596 15 20.75C15 21.4404 15.5596 22 16.25 22Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M8.25 22C8.94036 22 9.5 21.4404 9.5 20.75C9.5 20.0596 8.94036 19.5 8.25 19.5C7.55964 19.5 7 20.0596 7 20.75C7 21.4404 7.55964 22 8.25 22Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M9 8H21",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./src/icons/customers.tsx

const CustomersIcon = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M18.14 21.62C17.26 21.88 16.22 22 15 22H8.99998C7.77998 22 6.73999 21.88 5.85999 21.62C6.07999 19.02 8.74998 16.97 12 16.97C15.25 16.97 17.92 19.02 18.14 21.62Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M15 2H9C4 2 2 4 2 9V15C2 18.78 3.14 20.85 5.86 21.62C6.08 19.02 8.75 16.97 12 16.97C15.25 16.97 17.92 19.02 18.14 21.62C20.86 20.85 22 18.78 22 15V9C22 4 20 2 15 2ZM12 14.17C10.02 14.17 8.42 12.56 8.42 10.58C8.42 8.60002 10.02 7 12 7C13.98 7 15.58 8.60002 15.58 10.58C15.58 12.56 13.98 14.17 12 14.17Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M15.58 10.58C15.58 12.56 13.98 14.17 12 14.17C10.02 14.17 8.41998 12.56 8.41998 10.58C8.41998 8.60002 10.02 7 12 7C13.98 7 15.58 8.60002 15.58 10.58Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};


// EXTERNAL MODULE: ./src/icons/suppliers.tsx
var suppliers = __webpack_require__(4816);
;// CONCATENATED MODULE: ./src/icons/reports.tsx

const ReportsIcon = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M8 12.2H15",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M8 16.2H12.38",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M10 6H14C16 6 16 5 16 4C16 2 15 2 14 2H10C9 2 8 2 8 4C8 6 9 6 10 6Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M16 4.02002C19.33 4.20002 21 5.43002 21 10V16C21 20 20 22 15 22H9C4 22 3 20 3 16V10C3 5.44002 4.67 4.20002 8 4.02002",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./src/icons/products.tsx

const ProductsIcon = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M19 8C20.6569 8 22 6.65685 22 5C22 3.34315 20.6569 2 19 2C17.3431 2 16 3.34315 16 5C16 6.65685 17.3431 8 19 8Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M7 13H12",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M7 17H16",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M14 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22H15C20 22 22 20 22 15V10",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./src/icons/tab-close.tsx

const TabCloseIcon = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "5",
        height: "8",
        viewBox: "0 0 5 8",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M-2.47955e-05 1.42491C-2.47955e-05 0.974909 0.204309 0.662242 0.612975 0.486909C1.02164 0.311576 1.38398 0.382575 1.69998 0.699908L4.29998 3.29991C4.39998 3.39991 4.47497 3.50824 4.52497 3.62491C4.57497 3.74158 4.59998 3.86658 4.59998 3.99991C4.59998 4.13324 4.57497 4.25824 4.52497 4.37491C4.47497 4.49158 4.39998 4.59991 4.29998 4.69991L1.69998 7.29991C1.38331 7.61658 1.02064 7.68724 0.611976 7.51191C0.203309 7.33658 -0.000691414 7.02424 -2.47955e-05 6.57491L-2.47955e-05 1.42491Z",
            fill: "white"
        })
    });
};


;// CONCATENATED MODULE: ./src/icons/product-floor.tsx

const ProductFloorIcon = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M13.01 2.92007L18.91 5.54007C20.61 6.29007 20.61 7.53007 18.91 8.28007L13.01 10.9001C12.34 11.2001 11.24 11.2001 10.57 10.9001L4.67002 8.28007C2.97002 7.53007 2.97002 6.29007 4.67002 5.54007L10.57 2.92007C11.24 2.62007 12.34 2.62007 13.01 2.92007Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M3 11C3 11.84 3.63 12.81 4.4 13.15L11.19 16.17C11.71 16.4 12.3 16.4 12.81 16.17L19.6 13.15C20.37 12.81 21 11.84 21 11",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M3 16C3 16.93 3.55 17.77 4.4 18.15L11.19 21.17C11.71 21.4 12.3 21.4 12.81 21.17L19.6 18.15C20.45 17.77 21 16.93 21 16",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};


;// CONCATENATED MODULE: ./src/icons/index.ts











/***/ }),

/***/ 4816:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ SuppliersIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const SuppliersIcon = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z",
                stroke: "white",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M17.15 13.8199L14.11 16.8599",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M6.84998 13.8199H17.15",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M6.84998 10.18L9.88998 7.14001",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M17.15 10.1801H6.84998",
                stroke: "white",
                strokeWidth: "1.5",
                strokeMiterlimit: "10",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};



/***/ }),

/***/ 1234:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ AdminAuthLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2565);
/* harmony import */ var _left_side__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8588);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5577);
/* harmony import */ var _use_admin_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6346);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_widgets__WEBPACK_IMPORTED_MODULE_1__, _left_side__WEBPACK_IMPORTED_MODULE_2__, _use_admin_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__]);
([_widgets__WEBPACK_IMPORTED_MODULE_1__, _left_side__WEBPACK_IMPORTED_MODULE_2__, _use_admin_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const AdminAuthLayout = ({ children  })=>{
    const { canAccess , navigate  } = (0,_use_admin_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__/* .useAuthLayoutHook */ .L)();
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_3__/* .useStyle */ .X)({});
    if (typeof canAccess === "boolean") {
        if (canAccess) {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: clasess.container,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_left_side__WEBPACK_IMPORTED_MODULE_2__/* .LeftSideLayout */ .b, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        style: clasess.rightContainer,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: clasess.headerContainer,
                                children: "Header"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: clasess.bodyContainer,
                                children: children
                            })
                        ]
                    })
                ]
            });
        } else {
            navigate("/admin/login");
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
        }
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets__WEBPACK_IMPORTED_MODULE_1__/* .WaitingAuth */ .u2, {});
    }
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5703:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* reexport safe */ _admin_auth_layout__WEBPACK_IMPORTED_MODULE_0__.K)
/* harmony export */ });
/* harmony import */ var _admin_auth_layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1234);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_admin_auth_layout__WEBPACK_IMPORTED_MODULE_0__]);
_admin_auth_layout__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8588:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ LeftSideLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5577);
/* harmony import */ var _tab__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(955);
/* harmony import */ var _use_admin_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6346);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_1__, _tab__WEBPACK_IMPORTED_MODULE_3__, _use_admin_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_1__, _tab__WEBPACK_IMPORTED_MODULE_3__, _use_admin_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const LeftSideLayout = ()=>{
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_2__/* .useStyle */ .X)({});
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
    const { tabs  } = (0,_use_admin_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__/* .useAuthLayoutHook */ .L)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: clasess.leftContainer,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.logoContainer,
                children: "Admin panel"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.tabsContainer,
                children: tabs.map((tab)=>{
                    if (tab.isLine) {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: clasess.line
                        }, tab.key);
                    } else {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tab__WEBPACK_IMPORTED_MODULE_3__/* .Tab */ .O, {
                            tab: tab
                        }, tab.key);
                    }
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: clasess.poweredContainer,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.poweredByLbl,
                        children: t("login.poweredBy")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.gomakeByLbl,
                        children: t("login.GoMake")
                    })
                ]
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3254);
/* harmony import */ var _utils_adapter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2613);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




const useStyle = ({ isHover =false  })=>{
    const { primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeTheme */ .G)();
    const clasess = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return {
            container: {
                width: "100vw",
                height: "100vh",
                display: "flex",
                flexDirection: "row"
            },
            logoContainer: {
                display: "flex",
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(700, 18),
                color: "white"
            },
            leftContainer: {
                backgroundColor: primaryColor(500),
                width: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(281),
                height: "100vh",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                alignItems: "center",
                paddingRight: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(26),
                paddingLeft: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(26),
                paddingTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(40),
                paddingBottom: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(40)
            },
            rightContainer: {
                backgroundColor: "#FDFDFD",
                width: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(1468 - 281),
                height: "100vh",
                display: "flex",
                flexDirection: "column",
                padding: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(20)
            },
            headerContainer: {
                height: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(101),
                display: "flex",
                flexDirection: "column"
            },
            bodyContainer: {
                height: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(1024 - 101),
                display: "flex",
                flexDirection: "column"
            },
            poweredContainer: {
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                marginTop: 53
            },
            poweredByLbl: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(400, 12),
                color: "#FFF"
            },
            gomakeByLbl: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(400, 28),
                color: "#FFF"
            },
            ///Tab
            tabsContainer: {
                alignSelf: "flex-start",
                height: "100%",
                marginTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(46)
            },
            tabContainer: {
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "center",
                gap: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(8),
                marginTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(28),
                cursor: "pointer",
                opacity: isHover ? 0.5 : 1
            },
            tabTitle: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Inter */ .u.Inter(400, 16),
                color: "#FFF"
            },
            line: {
                border: "1px solid #FFFFFF",
                opacity: 0.4,
                width: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(207),
                marginTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(28),
                marginBottom: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(32)
            },
            tabList: {
                paddingTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(10),
                paddingLeft: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(40),
                paddingRight: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(40)
            },
            rotate90: {
                "-webkit-animation": "rotate90 0.5s forwards ",
                "-moz-animation": "rotate90 0.5s forwards ",
                animation: "rotate90 0.5s forwards "
            }
        };
    }, [
        isHover
    ]);
    return {
        clasess
    };
};



/***/ }),

/***/ 955:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ Tab)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5604);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5577);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
react_i18next__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Tab = ({ tab  })=>{
    const [isListOpen, setIsListOpen] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [isHover, setIsHover] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_5__/* .useStyle */ .X)({
        isHover
    });
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const handleMouseEnter = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        setIsHover(true);
    }, []);
    const handleMouseLeave = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        setIsHover(false);
    }, []);
    const onClickTab = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        if (tab.isList) {
            setIsListOpen(!isListOpen);
        }
    }, [
        tab,
        isListOpen,
        setIsListOpen
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: clasess.tabContainer,
                onMouseEnter: handleMouseEnter,
                onMouseLeave: handleMouseLeave,
                onClick: onClickTab,
                children: [
                    tab.isList && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: isListOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: clasess.rotate90,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_1__/* .TabCloseIcon */ .$9, {})
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_1__/* .TabCloseIcon */ .$9, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: tab.icon()
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.tabTitle,
                        children: tab.title
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Collapse, {
                in: isListOpen,
                children: tab.list?.map((list)=>{
                    console.log({
                        list
                    });
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.tabList,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: clasess.tabTitle,
                            children: list.title
                        })
                    }, list.key);
                })
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6346:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ useAuthLayoutHook)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5604);
/* harmony import */ var _icons_suppliers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4816);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
([_hooks__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const useAuthLayoutHook = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const { isAuth  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useGomakeAdminAuth */ .H)();
    const { navigate  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useGomakeRouter */ .VS)();
    const [canAccess, setCanAccess] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(null);
    const tabs = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        return [
            {
                isLine: false,
                key: "home",
                title: t("tabs.home"),
                path: "/home",
                isList: false,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .HomeIcon */ .tv, {});
                }
            },
            {
                isLine: false,
                key: "productFloor",
                title: t("tabs.productFloor"),
                path: "/product-floor",
                isList: false,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .ProductFloorIcon */ .pA, {});
                }
            },
            {
                isLine: true,
                key: "line_1"
            },
            {
                isLine: false,
                key: "products",
                title: t("tabs.products"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .ProductsIcon */ .bp, {});
                }
            },
            {
                isLine: false,
                key: "sales",
                title: t("tabs.sales"),
                path: "/product-floor",
                isList: true,
                list: [
                    {
                        key: "add",
                        title: t("tabs.addSales"),
                        path: "/sales/add"
                    },
                    {
                        key: "list",
                        title: t("tabs.listSales"),
                        path: "/sales/list"
                    }
                ],
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .SalesIcon */ ._6, {});
                }
            },
            {
                isLine: false,
                key: "shoping",
                title: t("tabs.shoping"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .ShopingIcon */ .x9, {});
                }
            },
            {
                isLine: false,
                key: "customers",
                title: t("tabs.customers"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .CustomersIcon */ .aE, {});
                }
            },
            {
                isLine: false,
                key: "suppliers",
                title: t("tabs.suppliers"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons_suppliers__WEBPACK_IMPORTED_MODULE_3__/* .SuppliersIcon */ ._, {});
                }
            },
            {
                isLine: false,
                key: "reports",
                title: t("tabs.reports"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .ReportsIcon */ .JM, {});
                }
            }
        ];
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (typeof isAuth === "boolean") {
            setCanAccess(isAuth);
        }
    }, [
        isAuth
    ]);
    return {
        tabs,
        canAccess,
        navigate
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4330:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ CustomerAuthLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2565);
/* harmony import */ var _left_side__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6499);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(495);
/* harmony import */ var _use_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9090);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_widgets__WEBPACK_IMPORTED_MODULE_1__, _left_side__WEBPACK_IMPORTED_MODULE_2__, _use_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__]);
([_widgets__WEBPACK_IMPORTED_MODULE_1__, _left_side__WEBPACK_IMPORTED_MODULE_2__, _use_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const CustomerAuthLayout = ({ children  })=>{
    const { canAccess , navigate  } = (0,_use_auth_layout_hook__WEBPACK_IMPORTED_MODULE_4__/* .useAuthLayoutHook */ .L)();
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_3__/* .useStyle */ .X)({});
    if (typeof canAccess === "boolean") {
        if (canAccess) {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: clasess.container,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_left_side__WEBPACK_IMPORTED_MODULE_2__/* .LeftSideLayout */ .b, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        style: clasess.rightContainer,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: clasess.headerContainer,
                                children: "Header"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: clasess.bodyContainer,
                                children: children
                            })
                        ]
                    })
                ]
            });
        } else {
            navigate("/login");
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
        }
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets__WEBPACK_IMPORTED_MODULE_1__/* .WaitingAuth */ .u2, {});
    }
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2177:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* reexport safe */ _customer_auth_layout__WEBPACK_IMPORTED_MODULE_0__.F)
/* harmony export */ });
/* harmony import */ var _customer_auth_layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4330);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_customer_auth_layout__WEBPACK_IMPORTED_MODULE_0__]);
_customer_auth_layout__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6499:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ LeftSideLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(495);
/* harmony import */ var _tab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4447);
/* harmony import */ var _use_auth_layout_hook__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9090);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _tab__WEBPACK_IMPORTED_MODULE_4__, _use_auth_layout_hook__WEBPACK_IMPORTED_MODULE_5__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _tab__WEBPACK_IMPORTED_MODULE_4__, _use_auth_layout_hook__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const LeftSideLayout = ()=>{
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_3__/* .useStyle */ .X)({});
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const { tabs  } = (0,_use_auth_layout_hook__WEBPACK_IMPORTED_MODULE_5__/* .useAuthLayoutHook */ .L)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: clasess.leftContainer,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.logoContainer,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    src: "https://i.ibb.co/wzpwSq6/Group-1239.png",
                    alt: "logo",
                    width: 100,
                    height: 100
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.tabsContainer,
                children: tabs.map((tab)=>{
                    if (tab.isLine) {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: clasess.line
                        }, tab.key);
                    } else {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tab__WEBPACK_IMPORTED_MODULE_4__/* .Tab */ .O, {
                            tab: tab
                        }, tab.key);
                    }
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: clasess.poweredContainer,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.poweredByLbl,
                        children: t("login.poweredBy")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.gomakeByLbl,
                        children: t("login.GoMake")
                    })
                ]
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3254);
/* harmony import */ var _utils_adapter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2613);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




const useStyle = ({ isHover =false  })=>{
    const { primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeTheme */ .G)();
    const clasess = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return {
            container: {
                width: "100vw",
                height: "100vh",
                display: "flex",
                flexDirection: "row"
            },
            logoContainer: {
                display: "flex"
            },
            leftContainer: {
                backgroundColor: primaryColor(500),
                width: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(281),
                height: "100vh",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                alignItems: "center",
                paddingRight: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(26),
                paddingLeft: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(26),
                paddingTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(40),
                paddingBottom: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(40)
            },
            rightContainer: {
                backgroundColor: "#FDFDFD",
                width: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(1468 - 281),
                height: "100vh",
                display: "flex",
                flexDirection: "column",
                padding: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(20),
                overflow: "auto"
            },
            headerContainer: {
                height: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(101),
                display: "flex",
                flexDirection: "column"
            },
            bodyContainer: {
                height: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(1024 - 101),
                display: "flex",
                flexDirection: "column"
            },
            poweredContainer: {
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                marginTop: 53
            },
            poweredByLbl: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(400, 12),
                color: "#FFF"
            },
            gomakeByLbl: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(400, 28),
                color: "#FFF"
            },
            ///Tab
            tabsContainer: {
                alignSelf: "flex-start",
                height: "100%",
                marginTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(46)
            },
            tabContainer: {
                display: "flex",
                flexDirection: "row",
                justifyContent: "flex-start",
                alignItems: "center",
                gap: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(8),
                marginTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(28),
                cursor: "pointer",
                opacity: isHover ? 0.5 : 1
            },
            tabTitle: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Inter */ .u.Inter(400, 16),
                color: "#FFF"
            },
            line: {
                border: "1px solid #FFFFFF",
                opacity: 0.4,
                width: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(207),
                marginTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(28),
                marginBottom: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertHeightToVH */ .x)(32)
            },
            tabList: {
                paddingTop: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(10),
                paddingLeft: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(40),
                paddingRight: (0,_utils_adapter__WEBPACK_IMPORTED_MODULE_3__/* .convertWidthToVW */ .E)(40)
            },
            rotate90: {
                "-webkit-animation": "rotate90 0.5s forwards ",
                "-moz-animation": "rotate90 0.5s forwards ",
                animation: "rotate90 0.5s forwards "
            }
        };
    }, [
        isHover
    ]);
    return {
        clasess
    };
};



/***/ }),

/***/ 4447:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ Tab)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5604);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
react_i18next__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Tab = ({ tab  })=>{
    const [isListOpen, setIsListOpen] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [isHover, setIsHover] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_5__/* .useStyle */ .X)({
        isHover
    });
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const handleMouseEnter = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        setIsHover(true);
    }, []);
    const handleMouseLeave = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        setIsHover(false);
    }, []);
    const onClickTab = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        if (tab.isList) {
            setIsListOpen(!isListOpen);
        }
    }, [
        tab,
        isListOpen,
        setIsListOpen
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: clasess.tabContainer,
                onMouseEnter: handleMouseEnter,
                onMouseLeave: handleMouseLeave,
                onClick: onClickTab,
                children: [
                    tab.isList && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: isListOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: clasess.rotate90,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_1__/* .TabCloseIcon */ .$9, {})
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_1__/* .TabCloseIcon */ .$9, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: tab.icon()
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.tabTitle,
                        children: tab.title
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Collapse, {
                in: isListOpen,
                children: tab.list?.map((list)=>{
                    console.log({
                        list
                    });
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.tabList,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: clasess.tabTitle,
                            children: list.title
                        })
                    }, list.key);
                })
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9090:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ useAuthLayoutHook)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5604);
/* harmony import */ var _icons_suppliers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4816);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
([_hooks__WEBPACK_IMPORTED_MODULE_1__, react_i18next__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const useAuthLayoutHook = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const { isAuth  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useGomakeAuth */ .Yc)();
    const { navigate  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useGomakeRouter */ .VS)();
    const [canAccess, setCanAccess] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(null);
    const tabs = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        return [
            {
                isLine: false,
                key: "home",
                title: t("tabs.home"),
                path: "/home",
                isList: false,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .HomeIcon */ .tv, {});
                }
            },
            {
                isLine: false,
                key: "productFloor",
                title: t("tabs.productFloor"),
                path: "/product-floor",
                isList: false,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .ProductFloorIcon */ .pA, {});
                }
            },
            {
                isLine: true,
                key: "line_1"
            },
            {
                isLine: false,
                key: "products",
                title: t("tabs.products"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .ProductsIcon */ .bp, {});
                }
            },
            {
                isLine: false,
                key: "sales",
                title: t("tabs.sales"),
                path: "/product-floor",
                isList: true,
                list: [
                    {
                        key: "add",
                        title: t("tabs.addSales"),
                        path: "/sales/add"
                    },
                    {
                        key: "list",
                        title: t("tabs.listSales"),
                        path: "/sales/list"
                    }
                ],
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .SalesIcon */ ._6, {});
                }
            },
            {
                isLine: false,
                key: "shoping",
                title: t("tabs.shoping"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .ShopingIcon */ .x9, {});
                }
            },
            {
                isLine: false,
                key: "customers",
                title: t("tabs.customers"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .CustomersIcon */ .aE, {});
                }
            },
            {
                isLine: false,
                key: "suppliers",
                title: t("tabs.suppliers"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons_suppliers__WEBPACK_IMPORTED_MODULE_3__/* .SuppliersIcon */ ._, {});
                }
            },
            {
                isLine: false,
                key: "reports",
                title: t("tabs.reports"),
                path: "/product-floor",
                isList: true,
                icon: ()=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons__WEBPACK_IMPORTED_MODULE_2__/* .ReportsIcon */ .JM, {});
                }
            }
        ];
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (typeof isAuth === "boolean") {
            setCanAccess(isAuth);
        }
    }, [
        isAuth
    ]);
    return {
        tabs,
        canAccess,
        navigate
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9036:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FA": () => (/* reexport safe */ _customer_auth_layout__WEBPACK_IMPORTED_MODULE_0__.F),
/* harmony export */   "Kn": () => (/* reexport safe */ _admin_auth_layout__WEBPACK_IMPORTED_MODULE_1__.K)
/* harmony export */ });
/* harmony import */ var _customer_auth_layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2177);
/* harmony import */ var _admin_auth_layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5703);
/* harmony import */ var _non_auth_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1117);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_customer_auth_layout__WEBPACK_IMPORTED_MODULE_0__, _admin_auth_layout__WEBPACK_IMPORTED_MODULE_1__]);
([_customer_auth_layout__WEBPACK_IMPORTED_MODULE_0__, _admin_auth_layout__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1117:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: NonAuthLayout

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/layouts/non-auth-layout/use-non-auth-layout-hook.ts

const use_non_auth_layout_hook_useNonAuthLayoutHook = ()=>{
    const [isAuth, setIsAuth] = useState(false);
    const [isAuthCheckDone, setIsAuthCheckDone] = useState(false);
    useEffect(()=>{
        setIsAuth(true);
        setTimeout(()=>{
            setIsAuthCheckDone(true);
        }, 1000);
    }, []);
    return {
        isAuth,
        isAuthCheckDone
    };
};


;// CONCATENATED MODULE: ./src/layouts/non-auth-layout/non-auth-layout.tsx


const NonAuthLayout = ({ children  })=>{
    const { isAuth , isAuthCheckDone  } = useNonAuthLayoutHook();
    if (isAuth) {
        return /*#__PURE__*/ _jsx("div", {
            children: children
        });
    } else {
        if (isAuthCheckDone) {
            return /*#__PURE__*/ _jsx("div", {
                children: "Not auth"
            });
        } else {
            return /*#__PURE__*/ _jsx("div", {
                children: "Waiting auth...."
            });
        }
    }
};


;// CONCATENATED MODULE: ./src/layouts/non-auth-layout/index.ts



/***/ }),

/***/ 2613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ convertWidthToVW),
/* harmony export */   "x": () => (/* binding */ convertHeightToVH)
/* harmony export */ });
const convertWidthToVW = (width)=>{
    return `${width / 1468 * 100}vw`;
};
const convertHeightToVH = (width)=>{
    return `${width / 1024 * 100}vh`;
};


/***/ })

};
;