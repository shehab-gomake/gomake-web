(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5243:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9816);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(108);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_circle_progress_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3431);
/* harmony import */ var _styles_circle_progress_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_circle_progress_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2021);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
/* harmony import */ var _languages_ar_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5737);
/* harmony import */ var _languages_en_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9761);
/* harmony import */ var _languages_he_json__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9487);
/* harmony import */ var _providers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4015);
/* harmony import */ var _widgets__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2565);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__, _widgets__WEBPACK_IMPORTED_MODULE_11__]);
([i18next__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__, _widgets__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












i18next__WEBPACK_IMPORTED_MODULE_5__["default"].use(react_i18next__WEBPACK_IMPORTED_MODULE_6__.initReactI18next) // passes i18n down to react-i18next
.init({
    // the translations
    // (tip move them in a JSON file and import them,
    // or even better, manage them via a UI: https://react.i18next.com/guides/multiple-translation-files#manage-your-translations-with-a-management-gui)
    resources: {
        en: {
            translation: {
                ..._languages_en_json__WEBPACK_IMPORTED_MODULE_8__
            }
        },
        ar: {
            translation: {
                ..._languages_ar_json__WEBPACK_IMPORTED_MODULE_7__
            }
        },
        he: {
            translation: {
                ..._languages_he_json__WEBPACK_IMPORTED_MODULE_9__
            }
        }
    },
    lng: "he",
    fallbackLng: "en",
    interpolation: {
        escapeValue: false
    }
});
function App({ Component , pageProps  }) {
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(recoil__WEBPACK_IMPORTED_MODULE_4__.RecoilRoot, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_providers__WEBPACK_IMPORTED_MODULE_10__/* .ThemeProvider */ .f, {}),
            react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
                id: "353efb2f95367fb4",
                dynamic: [
                    t("direction")
                ],
                children: `html{direction:${t("direction")}}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps,
                className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default().dynamic([
                    [
                        "353efb2f95367fb4",
                        [
                            t("direction")
                        ]
                    ]
                ]) + " " + (pageProps && pageProps.className != null && pageProps.className || "")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets__WEBPACK_IMPORTED_MODULE_11__/* .GomakeLoading */ .Xj, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "f": () => (/* reexport */ ThemeProvider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/store/index.ts + 6 modules
var store = __webpack_require__(229);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(9755);
;// CONCATENATED MODULE: ./src/providers/theme-provider/theme-provider.tsx






const ThemeProvider = ()=>{
    const [theme, setTheme] = (0,external_recoil_.useRecoilState)(store/* themeState */.XG);
    (0,external_react_.useEffect)(()=>{
        if (false) {}
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
};


;// CONCATENATED MODULE: ./src/providers/theme-provider/index.tsx


;// CONCATENATED MODULE: ./src/providers/index.ts



/***/ }),

/***/ 3431:
/***/ (() => {



/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 7915:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material");

/***/ }),

/***/ 8198:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/AddBoxOutlined");

/***/ }),

/***/ 9560:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/AddTask");

/***/ }),

/***/ 8358:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/AssignmentTurnedInOutlined");

/***/ }),

/***/ 8088:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/DoNotDisturbOnOutlined");

/***/ }),

/***/ 4557:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ElectricBoltSharp");

/***/ }),

/***/ 6117:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/FactCheckOutlined");

/***/ }),

/***/ 960:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/HourglassTop");

/***/ }),

/***/ 4845:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 1347:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LocalPrintshopOutlined");

/***/ }),

/***/ 8017:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 8125:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Menu");

/***/ }),

/***/ 9271:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/MenuItem");

/***/ }),

/***/ 6042:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/TextField");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 4146:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 7418:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns/fp");

/***/ }),

/***/ 4558:
/***/ ((module) => {

"use strict";
module.exports = require("next/config");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 4304:
/***/ ((module) => {

"use strict";
module.exports = require("react-date-range");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

"use strict";
module.exports = require("recoil");

/***/ }),

/***/ 9816:
/***/ ((module) => {

"use strict";
module.exports = require("styled-jsx/style");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 7987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 5737:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"direction":"rtl","pageName":{"welcome":"مرحبا"},"login":{"welcome":"Welcome to our company","weAreExcited":"We\'re excited to work with you and deliver outstanding printing solutions that exceed your expectations.","poweredBy":"powered by","GoMake":"GoMake","rememberMe":"Remember me","login":"Login","username":"Username","email":"Email","password":"Password"},"dashboard-page":{"welcome":"Tasks dashboard"},"machines-list-widget":{"machinesList":"machines list"},"dashboard-widget":{"tasks":"Task\'s","today":"Today","tomorrow":"Tomorrow","chooseDate":"Choose Date","task":"Task","status":"Status","board_col_1":"Inner pages","board_col_2":"Inner pages 2","board_cover":"Cover","board_vorsats":"Vorsats"},"datepicker-component":{"chooseDate":"Choose Date","choose":"choose"},"tabs":{"home":"الرئيسية","productFloor":"Product Floor"}}');

/***/ }),

/***/ 9761:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"direction":"ltr","pageName":{"welcome":"welcome"},"login":{"welcome":"Welcome to our company","weAreExcited":"We\'re excited to work with you and deliver outstanding printing solutions that exceed your expectations.","poweredBy":"powered by","GoMake":"GoMake","rememberMe":"Remember me","login":"Login","username":"Username","email":"Email","password":"Password"},"dashboard-page":{"welcome":"Production dashboard","insertCode":"Insert code","submit":"submit"},"machines-list-widget":{"machinesList":"machines list"},"dashboard-widget":{"tasks":"Task\'s","today":"Today","tomorrow":"Tomorrow","chooseDate":"Choose Date","task":"Task","status":"Status","board_col_1":"In.page1","board_col_2":"In.page2","board_cover":"Cover","board_vorsats":"Vorsats","progress":"Production status","done":"Done","new":"New","inProcess":"In process","fault":"Fault","orderNumber":"Order","clients":"Clients","search":"Search","all":"All","waiting":"Waiting","shortWaiting":"Waiting","lateMissions":"Late","client":"Client"},"datepicker-component":{"chooseDate":"Choose Date","choose":"choose"},"tabs":{"home":"Home","productFloor":"Product Floor","products":"Products","sales":"Sales","shoping":"Shoping","customers":"Customers","suppliers":"Suppliers","reports":"Reports","addSales":"Add sales","listSales":"List sales"}}');

/***/ }),

/***/ 9487:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"direction":"rtl","pageName":{"welcome":"ברוך הבא"},"login":{"welcome":"Welcome to our company","weAreExcited":"We\'re excited to work with you and deliver outstanding printing solutions that exceed your expectations.","poweredBy":"powered by","GoMake":"GoMake","rememberMe":"Remember me","login":"Login","username":"Username","email":"Email","password":"Password"},"dashboard-page":{"welcome":"לוח בקרה לייצור","insertCode":"הכנס קוד","submit":"התחבר"},"machines-list-widget":{"machinesList":"רשימת מכונות"},"dashboard-widget":{"tasks":"משימות","today":"היום","tomorrow":"מחר","chooseDate":"בחר תאריך","task":"משימה","status":"מצב","board_col_1":"ע.פנימיים1","board_col_2":"ע.פנימיים2","board_cover":"כריכה","board_vorsats":"פורזאץ","progress":"מצב ייצור","done":"בוצע","new":"חדש","inProcess":"בתהליך","fault":"תקוע","orderNumber":"הזמנה","clients":"לקוחות","search":"חיפוש","all":"הכל","waiting":"ממתין לאישור","shortWaiting":"באישורים","lateMissions":"באיחור","client":"לקוח"},"datepicker-component":{"chooseDate":"בחר תאריך","choose":"בחר"},"tabs":{"home":"Home","productFloor":"Product Floor"},"status":{"ready":"מוכן"}}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [443,844,866], () => (__webpack_exec__(5243)));
module.exports = __webpack_exports__;

})();