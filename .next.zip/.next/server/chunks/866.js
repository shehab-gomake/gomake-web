"use strict";
exports.id = 866;
exports.ids = [866];
exports.modules = {

/***/ 1996:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/rocket.c1f71ca6.png","height":469,"width":267,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAi0lEQVR42gGAAH//AFJQoURFoDk/kkZLn1BPoQA+Pp2BfbC8q61uU4xMT6QAPDudpp2qv62Xj29tYFyfAGNprE9UeSgpVGVzi1tenQBZX6hBRmhHPE1XX3VPUpgAUU6hTkx5WWB9QEJkVVKWAEZOpW1Oirp1HJVla0BJowBDTKR4W4/FhUShc3pBSqQBjjNz1IcPcQAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});

/***/ }),

/***/ 1684:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ DashboardCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_dashboard_card_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6031);
/* harmony import */ var _components_progress_label_circle_progress__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(848);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store_boards_missions_status_filter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8067);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
react_i18next__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const DashboardCard = ({ label , value , bgColor , children , progressValue =0 , withProgressBar =false , status  })=>{
    const [selectedStatus, setStatus] = (0,recoil__WEBPACK_IMPORTED_MODULE_5__.useRecoilState)(_store_boards_missions_status_filter__WEBPACK_IMPORTED_MODULE_6__/* .boardsMissionsStatusFilterState */ .C);
    const isSelected = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(()=>{
        return status === selectedStatus;
    }, [
        selectedStatus
    ]);
    const { classes  } = (0,_components_dashboard_card_style__WEBPACK_IMPORTED_MODULE_2__/* .useStyle */ .X)(bgColor, isSelected());
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const handleOnClick = ()=>{
        if (status) {
            if (selectedStatus === status) {
                setStatus(null);
            } else {
                setStatus(status ? status : null);
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, {
        onClick: handleOnClick,
        style: classes.container,
        variant: "outlined",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: {
                            width: "60px"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: classes.iconWrapper,
                            children: children
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: classes.value,
                        children: value
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: classes.progressWrapper,
                        children: withProgressBar && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_progress_label_circle_progress__WEBPACK_IMPORTED_MODULE_3__/* .CircularProgressWithLabel */ .h, {
                                value: progressValue
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: classes.label,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: t(label)
                })
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5179:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* reexport safe */ _dashboard_card__WEBPACK_IMPORTED_MODULE_0__.I)
/* harmony export */ });
/* harmony import */ var _dashboard_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1684);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_dashboard_card__WEBPACK_IMPORTED_MODULE_0__]);
_dashboard_card__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);


const useStyle = (bgColor, selected)=>{
    const classes = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return {
            container: {
                height: "100%",
                width: "100%",
                borderRadius: "16px",
                padding: "20px 20px 5px 20px",
                backgroundColor: bgColor,
                cursor: "pointer",
                opacity: selected ? 0.5 : 1
            },
            label: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Poppins */ .u.Poppins(500, 40),
                color: "#FFFFFF",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                height: "50%",
                textAlign: "center",
                paddingBottom: "20px"
            },
            value: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Poppins */ .u.Poppins(600, 55),
                color: "#FFFFFF",
                textAlign: "center",
                flex: 1
            },
            iconWrapper: {
                backgroundColor: "white",
                opacity: "0.5",
                width: "40px",
                height: "40px",
                borderRadius: "50%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center"
            },
            progressWrapper: {
                minWidth: "60px"
            }
        };
    }, [
        selected
    ]);
    return {
        classes
    };
};



/***/ }),

/***/ 9382:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ GoMakeDatepicker)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_date_range__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4304);
/* harmony import */ var react_date_range__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_date_range__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1412);
/* harmony import */ var _components_datepicker_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1332);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_date_range_dist_styles_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(886);
/* harmony import */ var react_date_range_dist_styles_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_date_range_dist_styles_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_date_range_dist_theme_default_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8130);
/* harmony import */ var react_date_range_dist_theme_default_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_date_range_dist_theme_default_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_AddBoxOutlined__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8198);
/* harmony import */ var _mui_icons_material_AddBoxOutlined__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddBoxOutlined__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _shared_constant__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6057);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6183);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7987);
/* harmony import */ var next_dist_client_components_react_dev_overlay_internal_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3884);
/* harmony import */ var next_dist_client_components_react_dev_overlay_internal_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_react_dev_overlay_internal_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_11__, react_i18next__WEBPACK_IMPORTED_MODULE_12__]);
([_hooks__WEBPACK_IMPORTED_MODULE_11__, react_i18next__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const GoMakeDatepicker = ({})=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_12__.useTranslation)();
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({
        selection: {
            ..._shared_constant__WEBPACK_IMPORTED_MODULE_10__/* .TODAY_DATE_RANGE */ .Bz,
            key: "selection"
        }
    });
    const [openDatepicker, setOpenDatepicker] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { classes  } = (0,_components_datepicker_style__WEBPACK_IMPORTED_MODULE_4__/* .useStyle */ .X)();
    const { newDateSelected  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_11__/* .useGomakeDateRange */ .pb)();
    const handleSelectDates = ()=>{
        setOpenDatepicker(false);
        newDateSelected(state.selection);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_8___default()), {
                style: classes.button,
                onClick: ()=>setOpenDatepicker(true),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddBoxOutlined__WEBPACK_IMPORTED_MODULE_9___default()), {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: t("datepicker-component.chooseDate")
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Modal, {
                open: openDatepicker,
                "aria-labelledby": "modal-modal-title",
                "aria-describedby": "modal-modal-description",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    style: classes.datepickerContainer,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                                onClick: ()=>setOpenDatepicker(false),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_dist_client_components_react_dev_overlay_internal_icons_CloseIcon__WEBPACK_IMPORTED_MODULE_13__.CloseIcon, {})
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_date_range__WEBPACK_IMPORTED_MODULE_2__.DateRangePicker, {
                            onChange: (item)=>setState({
                                    ...state,
                                    ...item
                                }),
                            months: 1,
                            direction: "vertical",
                            scroll: {
                                enabled: false
                            },
                            ranges: [
                                state.selection
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: {
                                    textAlign: "center"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_3__/* .GomakePrimaryButton */ .tm, {
                                    onClick: handleSelectDates,
                                    children: t("datepicker-component.choose")
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9262:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* reexport safe */ _datepicker__WEBPACK_IMPORTED_MODULE_0__.G)
/* harmony export */ });
/* harmony import */ var _datepicker__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9382);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_datepicker__WEBPACK_IMPORTED_MODULE_0__]);
_datepicker__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);


const useStyle = ()=>{
    const classes = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return {
            button: {
                width: "163px",
                height: "40px",
                borderRadius: "10px",
                border: "1px solid #504FA1",
                backgroundColor: "inherit",
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(500, 16),
                cursor: "pointer",
                color: "#504FA1"
            },
            datepickerContainer: {
                direction: "ltr",
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                backgroundColor: "#fff",
                padding: "5px",
                borderRadius: "16px"
            }
        };
    }, []);
    return {
        classes
    };
};



/***/ }),

/***/ 1412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "yL": () => (/* reexport */ ComponentName),
  "tm": () => (/* reexport */ GomakePrimaryButton),
  "Jw": () => (/* reexport */ GomakeTextInput)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/components/component-name/style.ts

const useStyle = ()=>{
    const clasess = (0,external_react_.useMemo)(()=>{
        return {
            container: {
            }
        };
    }, []);
    return {
        clasess
    };
};


;// CONCATENATED MODULE: ./src/components/component-name/component-name.tsx


const ComponentName = ({ text  })=>{
    const { clasess  } = useStyle();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: clasess.container,
        children: text
    });
};


;// CONCATENATED MODULE: ./src/components/component-name/index.ts


// EXTERNAL MODULE: external "@mui/material/TextField"
var TextField_ = __webpack_require__(6042);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField_);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: ./src/hooks/use-gomake-thme.ts
var use_gomake_thme = __webpack_require__(3254);
;// CONCATENATED MODULE: ./src/components/text-input/text-input.tsx





const StyledTextField = (0,styles_.styled)((TextField_default()), {
    shouldForwardProp: (propName)=>propName !== "secondColor" && propName !== "primaryColor" && propName !== "errorColor"
})((props)=>({
        width: "100%",
        input: {
            backgroundColor: "#FFFFFF",
            boxSizing: "border-box",
            borderRadius: props?.style?.borderRadius || 4,
            height: 56,
            fontFamily: "Jost",
            fontStyle: "normal",
            fontWeight: 300,
            fontSize: 14,
            lineHeight: "21px",
            display: "flex",
            alignItems: "center",
            width: "100%",
            color: props.error ? `${props.errorColor(300)}` : `${props.primaryColor(300)}`,
            ...props.style
        },
        "& .MuiOutlinedInput-root": {
            "&:hover fieldset": {
                border: props.error ? `2px solid ${props.errorColor(300)}` : `2px solid #B9B9D9`
            },
            "& fieldset": {
                border: props.error ? `1px solid ${props.errorColor(300)}` : `1px solid #B9B9D9`,
                boxSizing: "border-box",
                borderRadius: props?.style?.borderRadius || 4,
                width: "100%"
            },
            "&.Mui-focused fieldset": {
                borderColor: props.error ? `${props.errorColor(300)}` : "#B9B9D9",
                borderRadius: props?.style?.borderRadius || 4,
                width: "100%"
            }
        }
    }));
const GomakeTextInput = ({ labelText , value , onChange , style , error , type , disabled , placeholder , onKeyDown , multiline , InputProps  })=>{
    const { primaryColor , secondColor , errorColor  } = (0,use_gomake_thme/* useGomakeTheme */.G)();
    return /*#__PURE__*/ jsx_runtime_.jsx(StyledTextField, {
        value: value,
        onChange: onChange,
        style: style,
        error: error,
        type: type,
        disabled: disabled,
        placeholder: placeholder,
        onKeyDown: onKeyDown,
        multiline: multiline,
        InputProps: InputProps,
        // @ts-ignore
        secondColor: secondColor,
        primaryColor: primaryColor,
        errorColor: errorColor
    });
};


;// CONCATENATED MODULE: ./src/components/text-input/index.tsx


// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(3819);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: ./src/utils/font-family.ts
var font_family = __webpack_require__(4680);
;// CONCATENATED MODULE: ./src/components/button/button.tsx






const StyledButton = (0,styles_.styled)((Button_default()), {
    shouldForwardProp: (propName)=>propName !== "secondColor" && propName !== "primaryColor" && propName !== "errorColor"
})((props)=>({
        boxShadow: "none",
        textTransform: "none",
        padding: "14px",
        lineHeight: 1.5,
        backgroundColor: props.primaryColor(500),
        borderColor: "#FFFFFF",
        height: 56,
        borderRadius: 4,
        gap: 7,
        color: "#FFFFFF",
        "&:hover": {
            letterSpacing: "0.1em",
            backgroundColor: props.primaryColor(500)
        },
        transition: "0.25s",
        width: "100%",
        ...font_family/* FONT_FAMILY.Lexend */.u.Lexend(500, 16)
    }));
const GomakePrimaryButton = ({ ...props })=>{
    const { primaryColor  } = (0,use_gomake_thme/* useGomakeTheme */.G)();
    return /*#__PURE__*/ jsx_runtime_.jsx(StyledButton, {
        ...props,
        // @ts-ignore
        primaryColor: primaryColor,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            style: {
                display: "flex",
                width: "100%",
                justifyContent: "space-between",
                alignItems: "center"
            },
            children: [
                props.leftIcon && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    style: {
                        width: "15%",
                        display: "flex",
                        justifyContent: "center ",
                        alignItems: "center"
                    },
                    children: props.leftIcon
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    style: {
                        width: props.leftIcon ? "85%" : "100%"
                    },
                    children: props.children
                })
            ]
        })
    });
};


;// CONCATENATED MODULE: ./src/components/button/index.tsx


;// CONCATENATED MODULE: ./src/components/index.ts





/***/ }),

/***/ 848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ CircularProgressWithLabel)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


const CircularProgressWithLabel = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            position: "relative",
            display: "inline-flex"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, {
                variant: "determinate",
                size: 60,
                thickness: 6,
                ...props,
                className: "foreground"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, {
                variant: "determinate",
                className: "background",
                thickness: 6,
                size: 60,
                value: 100 - props.value
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    top: 0,
                    left: 0,
                    bottom: 0,
                    right: 0,
                    position: "absolute",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                    variant: "caption",
                    component: "div",
                    color: "white",
                    fontSize: "16px",
                    fontWeight: 600,
                    children: `${Math.round(props.value)}%`
                })
            })
        ]
    });
};



/***/ }),

/***/ 8686:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* reexport safe */ _status_view__WEBPACK_IMPORTED_MODULE_0__.l)
/* harmony export */ });
/* harmony import */ var _status_view__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8830);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_status_view__WEBPACK_IMPORTED_MODULE_0__]);
_status_view__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8830:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ StatusView)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_status_view_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6699);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const StatusView = ({ status , style ={} , label  })=>{
    const { classes  } = (0,_components_status_view_style__WEBPACK_IMPORTED_MODULE_1__/* .useStyle */ .X)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const styles = {
        ...classes[label ? "label" : "circle"],
        ...classes[status],
        ...style
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: styles,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            children: label && t(label).slice(0, 10)
        })
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6699:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8718);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3254);




const useStyle = ()=>{
    const { theme , successColor , errorColor , warningColor , secondColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_3__/* .useGomakeTheme */ .G)();
    const classes = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return {
            circle: {
                width: "20px",
                height: "20px",
                borderRadius: "50%",
                boxSizing: "border-box"
            },
            [_shared__WEBPACK_IMPORTED_MODULE_2__/* .EStatus.DONE */ .o.DONE]: {
                backgroundColor: successColor(500),
                color: successColor(700)
            },
            [_shared__WEBPACK_IMPORTED_MODULE_2__/* .EStatus.FAULT */ .o.FAULT]: {
                backgroundColor: errorColor(500),
                color: errorColor(700)
            },
            [_shared__WEBPACK_IMPORTED_MODULE_2__/* .EStatus.IN_PROCESS */ .o.IN_PROCESS]: {
                backgroundColor: warningColor(500),
                color: warningColor(700)
            },
            [_shared__WEBPACK_IMPORTED_MODULE_2__/* .EStatus.NOT_YET */ .o.NOT_YET]: {
                backgroundColor: "#fff",
                border: "3px solid " + warningColor(500),
                color: warningColor(700)
            },
            [_shared__WEBPACK_IMPORTED_MODULE_2__/* .EStatus.WAITING */ .o.WAITING]: {
                backgroundColor: secondColor(300),
                color: secondColor(700)
            },
            label: {
                width: "99px",
                height: "25px",
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Heebo */ .u.Heebo(400, 14),
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                textAlign: "center",
                // padding: '50px 0',
                overFlow: "hidden",
                borderRadius: "8px"
            }
        };
    }, [
        theme
    ]);
    return {
        classes
    };
};



/***/ }),

/***/ 6704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4558);
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_0__);

let config = {};
if (next_config__WEBPACK_IMPORTED_MODULE_0___default()()) {
    const { publicRuntimeConfig , serverRuntimeConfig  } = next_config__WEBPACK_IMPORTED_MODULE_0___default()();
    config = {
        api_server: publicRuntimeConfig.API_SERVER || serverRuntimeConfig.API_SERVER,
        google_place_service: publicRuntimeConfig.GOOGLE_PLACE_SERVICE || serverRuntimeConfig.GOOGLE_PLACE_SERVICE,
        enviroment: publicRuntimeConfig.ENVIROMENT,
        user_app: publicRuntimeConfig.USER_APP_URL || serverRuntimeConfig.USER_APP_URL,
        hs_token: publicRuntimeConfig.HS_TOKEN || serverRuntimeConfig.HS_TOKEN,
        hs_service_name: publicRuntimeConfig.HS_SERVICE_NAME || serverRuntimeConfig.HS_SERVICE_NAME,
        hs_environment: publicRuntimeConfig.HS_ENVIRONMENT || serverRuntimeConfig.HS_ENVIRONMENT
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (config);


/***/ }),

/***/ 6183:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* reexport safe */ _use_gomake_admin_auth__WEBPACK_IMPORTED_MODULE_2__.H),
/* harmony export */   "S2": () => (/* reexport safe */ _use_gomake_axios__WEBPACK_IMPORTED_MODULE_0__.S),
/* harmony export */   "VS": () => (/* reexport safe */ _use_gomake_router__WEBPACK_IMPORTED_MODULE_3__.V),
/* harmony export */   "Yc": () => (/* reexport safe */ _use_gomake_auth__WEBPACK_IMPORTED_MODULE_1__.Y),
/* harmony export */   "gB": () => (/* reexport safe */ _use_gomake_machines__WEBPACK_IMPORTED_MODULE_7__.g),
/* harmony export */   "pb": () => (/* reexport safe */ _use_gomake_date_range__WEBPACK_IMPORTED_MODULE_6__.p)
/* harmony export */ });
/* harmony import */ var _use_gomake_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3089);
/* harmony import */ var _use_gomake_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(884);
/* harmony import */ var _use_gomake_admin_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5816);
/* harmony import */ var _use_gomake_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1375);
/* harmony import */ var _use_customer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6625);
/* harmony import */ var _use_admin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1763);
/* harmony import */ var _use_gomake_date_range__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4702);
/* harmony import */ var _use_gomake_machines__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3391);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_use_gomake_axios__WEBPACK_IMPORTED_MODULE_0__, _use_gomake_auth__WEBPACK_IMPORTED_MODULE_1__, _use_gomake_admin_auth__WEBPACK_IMPORTED_MODULE_2__, _use_customer__WEBPACK_IMPORTED_MODULE_4__, _use_admin__WEBPACK_IMPORTED_MODULE_5__, _use_gomake_date_range__WEBPACK_IMPORTED_MODULE_6__, _use_gomake_machines__WEBPACK_IMPORTED_MODULE_7__]);
([_use_gomake_axios__WEBPACK_IMPORTED_MODULE_0__, _use_gomake_auth__WEBPACK_IMPORTED_MODULE_1__, _use_gomake_admin_auth__WEBPACK_IMPORTED_MODULE_2__, _use_customer__WEBPACK_IMPORTED_MODULE_4__, _use_admin__WEBPACK_IMPORTED_MODULE_5__, _use_gomake_date_range__WEBPACK_IMPORTED_MODULE_6__, _use_gomake_machines__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1763:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ useAdmin)
/* harmony export */ });
/* harmony import */ var _services_storage_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3443);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(229);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _use_gomake_axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3089);
/* harmony import */ var _use_gomake_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1375);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_use_gomake_axios__WEBPACK_IMPORTED_MODULE_4__]);
_use_gomake_axios__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const useAdmin = ()=>{
    const { callApi  } = (0,_use_gomake_axios__WEBPACK_IMPORTED_MODULE_4__/* .useGomakeAxios */ .S)();
    const [admin, setAdmin] = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilState)(_store__WEBPACK_IMPORTED_MODULE_1__/* .adminState */ .vi);
    const [permissions, setPermissions] = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilState)(_store__WEBPACK_IMPORTED_MODULE_1__/* .permissionsState */ .ey);
    const { navigate  } = (0,_use_gomake_router__WEBPACK_IMPORTED_MODULE_5__/* .useGomakeRouter */ .V)();
    const logOut = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        setAdmin({});
        (0,_services_storage_data__WEBPACK_IMPORTED_MODULE_0__/* .clearStorage */ .B$)();
        navigate("/");
    }, []);
    const validate = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(async ()=>{
        const validate = await callApi("GET", "/v1/admin/validate");
        if (validate?.success) {
            setAdmin(validate?.data?.data?.admin);
            //   setPermissions(validate?.data?.data?.permissions); will  be implemented later
            return true;
        }
        (0,_services_storage_data__WEBPACK_IMPORTED_MODULE_0__/* .clearStorage */ .B$)();
        navigate("/admin/login");
        return false;
    }, []);
    const checkPermission = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((permission)=>{
        let canAccess = false;
        const index = permissions.findIndex((item)=>item.route === permission);
        if (index !== -1) {
            canAccess = true;
        }
        return canAccess;
    }, [
        permissions
    ]);
    const getPermission = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((permission)=>{
        const _permissions = permissions.filter((item)=>item.route === permission);
        let op = "";
        if (_permissions[0]?.op === "read" || _permissions[1]?.op === "read" || _permissions[2]?.op === "read") {
            op = "read";
        }
        if (_permissions[0]?.op === "write" || _permissions[1]?.op === "write" || _permissions[2]?.op === "write") {
            op = "write";
        }
        if (_permissions[0]?.op === "admin" || _permissions[1]?.op === "admin" || _permissions[2]?.op === "admin") {
            op = "admin";
        }
        return {
            op
        };
    }, [
        permissions
    ]);
    return {
        admin,
        setAdmin,
        logOut,
        checkPermission,
        getPermission,
        setPermissions,
        validate
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6625:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ useCustomer)
/* harmony export */ });
/* harmony import */ var _services_storage_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3443);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(229);
/* harmony import */ var _store_permissions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3360);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _use_gomake_axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3089);
/* harmony import */ var _use_gomake_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1375);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_use_gomake_axios__WEBPACK_IMPORTED_MODULE_5__]);
_use_gomake_axios__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const useCustomer = ()=>{
    const { callApi  } = (0,_use_gomake_axios__WEBPACK_IMPORTED_MODULE_5__/* .useGomakeAxios */ .S)();
    const [user, setUser] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_store__WEBPACK_IMPORTED_MODULE_1__/* .userState */ .KL);
    const [adminsAutoComplate, setAdminsAutoComplate] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [permissions, setPermissions] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_store_permissions__WEBPACK_IMPORTED_MODULE_2__/* .permissionsState */ .e);
    const { navigate  } = (0,_use_gomake_router__WEBPACK_IMPORTED_MODULE_6__/* .useGomakeRouter */ .V)();
    const logOut = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>{
        setUser({});
        (0,_services_storage_data__WEBPACK_IMPORTED_MODULE_0__/* .clearStorage */ .B$)();
        navigate("/");
    }, []);
    const validate = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(async ()=>{
        const validate = await callApi("GET", "/v1/auth/validate");
        if (validate?.success) {
            setUser(validate?.data?.data?.customer);
            //   setPermissions(validate?.data?.data?.permissions); will  be implemented later
            return true;
        }
        (0,_services_storage_data__WEBPACK_IMPORTED_MODULE_0__/* .clearStorage */ .B$)();
        navigate("/login");
        return false;
    }, []);
    const checkPermission = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((permission)=>{
        let canAccess = false;
        const index = permissions.findIndex((item)=>item.route === permission);
        if (index !== -1) {
            canAccess = true;
        }
        return canAccess;
    }, [
        permissions
    ]);
    const getPermission = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((permission)=>{
        const _permissions = permissions.filter((item)=>item.route === permission);
        let op = "";
        if (_permissions[0]?.op === "read" || _permissions[1]?.op === "read" || _permissions[2]?.op === "read") {
            op = "read";
        }
        if (_permissions[0]?.op === "write" || _permissions[1]?.op === "write" || _permissions[2]?.op === "write") {
            op = "write";
        }
        if (_permissions[0]?.op === "admin" || _permissions[1]?.op === "admin" || _permissions[2]?.op === "admin") {
            op = "admin";
        }
        return {
            op
        };
    }, [
        permissions
    ]);
    return {
        adminsAutoComplate,
        user,
        setUser,
        logOut,
        checkPermission,
        getPermission,
        setPermissions,
        validate
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9416:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useDashboardLogout)
/* harmony export */ });
/* harmony import */ var _services_storage_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3443);

const useDashboardLogout = ()=>{
    const logout = ()=>{
        (0,_services_storage_data__WEBPACK_IMPORTED_MODULE_0__/* .clearStorage */ .B$)();
        window.location.reload();
    };
    return {
        logout
    };
};



/***/ }),

/***/ 5816:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ useGomakeAdminAuth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _use_admin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1763);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_use_admin__WEBPACK_IMPORTED_MODULE_1__]);
_use_admin__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const useGomakeAdminAuth = ()=>{
    const { admin , validate  } = (0,_use_admin__WEBPACK_IMPORTED_MODULE_1__/* .useAdmin */ .A)();
    const [isAuth, setIsAuth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const check = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async ()=>{
        setIsAuth(await validate());
    }, [
        setIsAuth
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        check();
    }, []);
    return {
        admin,
        isAuth
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 884:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ useGomakeAuth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _use_customer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6625);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_use_customer__WEBPACK_IMPORTED_MODULE_1__]);
_use_customer__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const useGomakeAuth = ()=>{
    const { user , validate  } = (0,_use_customer__WEBPACK_IMPORTED_MODULE_1__/* .useCustomer */ .O)();
    const [isAuth, setIsAuth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const check = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async ()=>{
        setIsAuth(await validate());
    }, [
        setIsAuth
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        check();
    }, []);
    return {
        user,
        isAuth
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3089:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ useGomakeAxios)
/* harmony export */ });
/* harmony import */ var _services_api_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9682);
/* harmony import */ var _store_loading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8072);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_api_request__WEBPACK_IMPORTED_MODULE_0__]);
_services_api_request__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// import { useRecoilState } from "recoil";
// import { loadgingState } from "../atoms";
// examplet to how its work
// const {callApi} = useGomakeAxios()
//const result = await callApi("POST","/v1/api/",{
//    "name":"test",
//    "age":20
// })
const useGomakeAxios = ()=>{
    const setLoading = (0,recoil__WEBPACK_IMPORTED_MODULE_2__.useSetRecoilState)(_store_loading__WEBPACK_IMPORTED_MODULE_1__/* .loadgingState */ .y);
    const callApi = async (method, url, data, lockScreen = true, secondServer = false)=>{
        if (lockScreen) {
            setLoading(true);
        }
        const result = await (0,_services_api_request__WEBPACK_IMPORTED_MODULE_0__/* .apiRequest */ .Nv)(method, url, data, secondServer);
        if (lockScreen) {
            setTimeout(()=>{
                setLoading(false);
            }, 500);
        }
        return result;
    };
    const lockScreen = async (ms)=>{
        setLoading(true);
        setTimeout(()=>{
            setLoading(false);
        }, ms);
    };
    return {
        callApi,
        lockScreen
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4702:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ useGomakeDateRange)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(229);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _shared_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6057);
/* harmony import */ var date_fns_fp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7418);
/* harmony import */ var date_fns_fp__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(date_fns_fp__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
react_i18next__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const useGomakeDateRange = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const { dates , action  } = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.useRecoilValue)(_store__WEBPACK_IMPORTED_MODULE_1__/* .dashboardDateState */ .Di);
    const setDate = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.useSetRecoilState)(_store__WEBPACK_IMPORTED_MODULE_1__/* .dashboardDateState */ .Di);
    const newDateSelected = (dateRange)=>{
        if (dateRange.endDate) {
            dateRange.endDate = (0,date_fns_fp__WEBPACK_IMPORTED_MODULE_4__.endOfDay)(dateRange.endDate);
            if (dateRange === _shared_constant__WEBPACK_IMPORTED_MODULE_3__/* .TODAY_DATE_RANGE */ .Bz) {
                setTodayDateRange();
                return;
            }
            if (dateRange === _shared_constant__WEBPACK_IMPORTED_MODULE_3__/* .TOMORROW_DATE_RANGE */ .fY) {
                setTomorrowDateRange();
                return;
            }
            setDate({
                dates: {
                    ...dateRange,
                    endDate: (0,date_fns_fp__WEBPACK_IMPORTED_MODULE_4__.endOfDay)(dateRange.endDate)
                },
                action: _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.DATE_RANGE_BOARDS */ .FW.DATE_RANGE_BOARDS
            });
        }
    };
    const setTodayDateRange = ()=>{
        setDate({
            dates: _shared_constant__WEBPACK_IMPORTED_MODULE_3__/* .TODAY_DATE_RANGE */ .Bz,
            action: _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.TODAY_BOARDS_MISSIONS */ .FW.TODAY_BOARDS_MISSIONS
        });
    };
    const setTomorrowDateRange = ()=>{
        setDate({
            dates: _shared_constant__WEBPACK_IMPORTED_MODULE_3__/* .TOMORROW_DATE_RANGE */ .fY,
            action: _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.TOMORROW_BOARDS_MISSIONS */ .FW.TOMORROW_BOARDS_MISSIONS
        });
    };
    const setLateBoardsMissions = ()=>{
        setDate({
            dates: {
                startDate: undefined,
                endDate: undefined
            },
            action: _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.LATE_BOARDS_MISSIONS */ .FW.LATE_BOARDS_MISSIONS
        });
    };
    const setAllBoardsMissions = ()=>{
        setDate({
            dates: {
                startDate: undefined,
                endDate: undefined
            },
            action: _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.ALL_BOARDS_MISSIONS */ .FW.ALL_BOARDS_MISSIONS
        });
    };
    const setLateToday = ()=>{
        setDate({
            dates: {
                startDate: undefined,
                endDate: undefined
            },
            action: _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.LATE_TODAY_BOARDS_MISSIONS */ .FW.LATE_TODAY_BOARDS_MISSIONS
        });
    };
    const selectedDateText = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        switch(action){
            case _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.TODAY_BOARDS_MISSIONS */ .FW.TODAY_BOARDS_MISSIONS:
                return t("dashboard-widget.today") + " " + t("dashboard-widget.tasks");
            case _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.TOMORROW_BOARDS_MISSIONS */ .FW.TOMORROW_BOARDS_MISSIONS:
                return t("dashboard-widget.tomorrow") + " " + t("dashboard-widget.tasks");
            case _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.LATE_BOARDS_MISSIONS */ .FW.LATE_BOARDS_MISSIONS:
                return t("dashboard-widget.tasks") + " " + t("dashboard-widget.lateMissions");
            case _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.LATE_TODAY_BOARDS_MISSIONS */ .FW.LATE_TODAY_BOARDS_MISSIONS:
                return t("dashboard-widget.tasks") + " " + t("dashboard-widget.today") + " & " + t("dashboard-widget.lateMissions");
            case _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.ALL_BOARDS_MISSIONS */ .FW.ALL_BOARDS_MISSIONS:
                return t("dashboard-widget.allTasks");
            case _store__WEBPACK_IMPORTED_MODULE_1__/* .DashboardActions.DATE_RANGE_BOARDS */ .FW.DATE_RANGE_BOARDS:
                return dates.endDate && dates.startDate && (0,_shared_constant__WEBPACK_IMPORTED_MODULE_3__/* .dateStringFormat */ .WC)(dates.startDate) + " - " + (0,_shared_constant__WEBPACK_IMPORTED_MODULE_3__/* .dateStringFormat */ .WC)(dates.endDate) + " " + t("dashboard-widget.tasks");
            default:
                return "";
        }
    }, [
        dates,
        action
    ]);
    return {
        newDateSelected,
        dates,
        setTodayDateRange,
        setTomorrowDateRange,
        selectedDateText,
        setLateBoardsMissions,
        setLateToday,
        action,
        setAllBoardsMissions
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3391:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ useGomakeMachines)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _store_machines__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5796);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_api_request__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9682);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_api_request__WEBPACK_IMPORTED_MODULE_3__]);
_services_api_request__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const useGomakeMachines = ()=>{
    const machines = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.useRecoilValue)(_store_machines__WEBPACK_IMPORTED_MODULE_1__/* .machinesListState */ .D);
    const setMachines = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.useSetRecoilState)(_store_machines__WEBPACK_IMPORTED_MODULE_1__/* .machinesListState */ .D);
    const getMachinesList = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        (0,_services_api_request__WEBPACK_IMPORTED_MODULE_3__/* .getApiRequest */ .jY)("/machines", {}, true).then((res)=>{
            if (res && res.data) {
                const machinesList = res.data.map((m)=>({
                        ...m,
                        checked: true
                    }));
                setMachines(machinesList);
            }
        });
    }, []);
    const getCheckedMachines = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        return machines.filter((machine)=>machine.checked);
    }, [
        machines
    ]);
    const setMachineChecked = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((machineId)=>{
        const updatedMachines = machines.map((machine)=>{
            if (machine.id === machineId) {
                return {
                    ...machine,
                    checked: !machine.checked
                };
            }
            return machine;
        });
        setMachines(updatedMachines);
    }, [
        machines
    ]);
    const addMachineProgress = (progress)=>{
        setMachines(machines.map((machine)=>progress[machine.id] ? {
                ...machine,
                progress: progress[machine.id]
            } : machine));
    };
    const checkAllMachines = ()=>{
        const isChecked = machines.every((machine)=>machine.checked);
        const updatedMachines = machines.map((machine)=>({
                ...machine,
                checked: !isChecked
            }));
        setMachines(updatedMachines);
    };
    return {
        getMachinesList,
        getCheckedMachines,
        setMachineChecked,
        machines,
        addMachineProgress,
        checkAllMachines
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1375:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ useGomakeRouter)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const useGomakeRouter = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
    const navigate = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((route, data)=>{
        router.push(route, data);
    }, [
        router
    ]);
    return {
        navigate
    };
};



/***/ }),

/***/ 3254:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ useGomakeTheme)
/* harmony export */ });
/* harmony import */ var _services_storage_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3443);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(229);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);




const useGomakeTheme = ()=>{
    const [theme, setTheme] = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilState)(_store__WEBPACK_IMPORTED_MODULE_1__/* .themeState */ .XG);
    const changedTheme = (theme)=>{
        setTheme(theme);
    };
    const changeThemeMode = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        const selectedTheme = theme.themeMode;
        (0,_services_storage_data__WEBPACK_IMPORTED_MODULE_0__/* .setItem */ .LS)("themeMode", selectedTheme === "dark" ? "light" : "dark");
    }, []);
    const getColor = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((pattern, degree)=>{
        if (degree >= 500) {
            // @ts-ignore
            return theme[pattern].dark[degree];
        }
        const selectedTheme = theme.themeMode;
        if (selectedTheme === "dark") {
            let darkDegree;
            switch(degree){
                case 500:
                    darkDegree = 500;
                    break;
                case 400:
                    darkDegree = 600;
                    break;
                case 300:
                    darkDegree = 700;
                    break;
                case 200:
                    darkDegree = 800;
                    break;
                case 100:
                    darkDegree = 900;
                    break;
                default:
                    break;
            }
            // @ts-ignore
            return theme[pattern].dark[darkDegree];
        } else {
            // @ts-ignore
            return theme[pattern].light[degree];
        }
    }, [
        theme
    ]);
    const primaryColor = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((degree)=>{
        return getColor("primary", degree);
    }, [
        theme
    ]);
    const secondColor = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((degree)=>{
        return getColor("second", degree);
    }, [
        theme
    ]);
    const successColor = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((degree)=>{
        return getColor("success", degree);
    }, [
        theme
    ]);
    const warningColor = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((degree)=>{
        return getColor("warning", degree);
    }, [
        theme
    ]);
    const errorColor = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((degree)=>{
        return getColor("error", degree);
    }, [
        theme
    ]);
    const neutralColor = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)((degree)=>{
        return getColor("neutral", degree);
    }, [
        theme
    ]);
    return {
        theme,
        changedTheme,
        changeThemeMode,
        successColor,
        secondColor,
        primaryColor,
        neutralColor,
        errorColor,
        warningColor
    };
};



/***/ }),

/***/ 9682:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nv": () => (/* binding */ apiRequest),
/* harmony export */   "jY": () => (/* binding */ getApiRequest),
/* harmony export */   "vw": () => (/* binding */ goMakeClientPrintHouseId)
/* harmony export */ });
/* unused harmony exports postApiRequest, putApiRequest, patchApiRequest, deleteApiRequest */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6704);
/* harmony import */ var _storage_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3443);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// import { clearStorage } from './storage'
const apiRequest = async (method = "GET", url, data = {}, secondServer = false)=>{
    try {
        const SERVER = _config__WEBPACK_IMPORTED_MODULE_1__/* ["default"].api_server */ .Z.api_server;
        // // if(safdsa){
        // //     trh
        // // }
        // const SERVER = 'http://localhost:3010';
        const SERVER2 = "https://production-service-prod.gomake.co.il";
        const reqUrl = secondServer ? SERVER2 + url : SERVER + url;
        const options = {
            method,
            url: reqUrl,
            data,
            responseType: "json",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                "project-name": "business-dashboard-widget",
                ...(0,_storage_data__WEBPACK_IMPORTED_MODULE_2__/* .getUserToken */ .Nh)() && {
                    "auth-token": (0,_storage_data__WEBPACK_IMPORTED_MODULE_2__/* .getUserToken */ .Nh)()
                },
                ...data.customAuth && {
                    "auth-token": data.customAuth
                },
                ...(0,_storage_data__WEBPACK_IMPORTED_MODULE_2__/* .getPrintHouseId */ .Hl)() && {
                    "printhouseid": (0,_storage_data__WEBPACK_IMPORTED_MODULE_2__/* .getPrintHouseId */ .Hl)()
                }
            }
        };
        if (method === "GET") {
            delete options["data"];
            options.params = {
                ...data
            };
        }
        const response = await (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])(options);
        if (response) {
            if (method === "GET") {
                delete options["data"];
                options.params = {
                    ...data
                };
                const offlineResponse = await (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])(options);
                localStorage.setItem(data?.offline, JSON.stringify(offlineResponse?.data));
            } else {
                localStorage.setItem(data?.offline, JSON.stringify(response?.data));
            }
            return {
                success: true,
                status: response?.status,
                message: response?.data?.message,
                data: response?.data
            };
        }
    } catch (err) {
        return {
            success: false,
            status: err?.response?.status,
            message: err?.response?.data?.message,
            errors: err?.response?.data?.errors,
            msg: err?.response?.data?.msg
        };
    }
};
const getApiRequest = async (url, data, secondServer)=>{
    return await apiRequest("GET", url, data, !!secondServer);
};
const postApiRequest = async (url, data)=>{
    return await apiRequest("POST", url, data);
};
const putApiRequest = async (url, data)=>{
    return await apiRequest("PUT", url, data);
};
const patchApiRequest = async (url, data)=>{
    return await apiRequest("PATCH", url, data);
};
const deleteApiRequest = async (url, data = {})=>{
    return await apiRequest("DELETE", url, data);
};
const goMakeClientPrintHouseId = async (method = "GET", code, data = {})=>{
    try {
        const reqUrl = "https://api-central-prd.gomake.co.il/api/printhouses/DashBoardLogin?code=" + code;
        const options = {
            method,
            url: reqUrl,
            data,
            responseType: "json",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json"
            }
        };
        if (method === "GET") {
            delete options["data"];
            options.params = {
                ...data
            };
        }
        const response = await (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])(options);
        if (response) {
            if (method === "GET") {
                delete options["data"];
                options.params = {
                    ...data
                };
                const offlineResponse = await (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])(options);
                localStorage.setItem(data?.offline, JSON.stringify(offlineResponse?.data));
            } else {
                localStorage.setItem(data?.offline, JSON.stringify(response?.data));
            }
            return {
                success: true,
                status: response?.status,
                message: response?.data?.message,
                data: response?.data
            };
        }
    } catch (err) {
        return {
            success: false,
            status: err?.response?.status,
            message: err?.response?.data?.message,
            errors: err?.response?.data?.errors,
            msg: err?.response?.data?.msg
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B$": () => (/* binding */ clearStorage),
/* harmony export */   "Hl": () => (/* binding */ getPrintHouseId),
/* harmony export */   "LS": () => (/* binding */ setItem),
/* harmony export */   "Nh": () => (/* binding */ getUserToken),
/* harmony export */   "Yr": () => (/* binding */ updateTokenStorage),
/* harmony export */   "sc": () => (/* binding */ updatePrintHouseIdHost),
/* harmony export */   "z_": () => (/* binding */ getPrintHouseHost)
/* harmony export */ });
/* unused harmony exports hasToken, getItem */
const STORAGE_KEYS = {
    printHouseId: "printhouseid",
    printHouseHost: "printHouseId"
};
const hasToken = ()=>{
    if (getUserToken()) return true;
    return false;
};
const getItem = (key, parse = false)=>{
    if (typeof localStorage !== "undefined") {
        let item = null;
        item = localStorage.getItem(key);
        if (parse) {
            return JSON.parse(item);
        }
        return item;
    }
};
const setItem = (key, value)=>{
    localStorage.setItem(key, value);
};
const getUserToken = ()=>{
    return getItem("auth-token");
};
const updateTokenStorage = (token)=>{
    setItem("auth-token", token);
};
const clearStorage = ()=>{
    localStorage.clear();
};
const getPrintHouseId = ()=>{
    return getItem(STORAGE_KEYS.printHouseId);
};
const getPrintHouseHost = ()=>{
    return getItem(STORAGE_KEYS.printHouseHost);
};
const updatePrintHouseIdHost = (id, host)=>{
    setItem(STORAGE_KEYS.printHouseId, id);
    setItem(STORAGE_KEYS.printHouseHost, host);
};


/***/ }),

/***/ 6057:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Bz": () => (/* reexport */ TODAY_DATE_RANGE),
  "fY": () => (/* reexport */ TOMORROW_DATE_RANGE),
  "cu": () => (/* reexport */ TYPE_MISSION_NAME_KEY),
  "WC": () => (/* reexport */ dateStringFormat)
});

// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(4146);
;// CONCATENATED MODULE: ./src/shared/constant/date.ts

const TODAY_DATE_RANGE = {
    startDate: (0,external_date_fns_.startOfToday)(),
    endDate: (0,external_date_fns_.endOfToday)()
};
const TOMORROW_DATE_RANGE = {
    startDate: (0,external_date_fns_.startOfDay)((0,external_date_fns_.addDays)(new Date(), 1)),
    endDate: (0,external_date_fns_.endOfDay)((0,external_date_fns_.addDays)(new Date(), 1))
};
const dateStringFormat = (inputDate)=>{
    let date, month, year;
    date = inputDate.getDate();
    month = inputDate.getMonth() + 1;
    year = inputDate.getFullYear();
    if (date < 10) {
        date = "0" + date;
    }
    if (month < 10) {
        month = "0" + month;
    }
    date = date.toString().padStart(2, "0");
    month = month.toString().padStart(2, "0");
    return `${date}/${month}/${year}`;
};


;// CONCATENATED MODULE: ./src/shared/enums/mission-type.ts
var EMissionType;
(function(EMissionType) {
    EMissionType[EMissionType["ENTIRE_COLUMNS_1"] = 0] = "ENTIRE_COLUMNS_1";
    EMissionType[EMissionType["ENTIRE_COLUMNS_2"] = 1] = "ENTIRE_COLUMNS_2";
    EMissionType[EMissionType["COVER"] = 2] = "COVER";
    EMissionType[EMissionType["VORSATZ"] = 3] = "VORSATZ";
})(EMissionType || (EMissionType = {}));

;// CONCATENATED MODULE: ./src/shared/constant/mission-type-translate-key.ts

const TYPE_MISSION_NAME_KEY = {
    [EMissionType.ENTIRE_COLUMNS_1]: "dashboard-widget.board_col_1",
    [EMissionType.ENTIRE_COLUMNS_2]: "dashboard-widget.board_col_2",
    [EMissionType.COVER]: "dashboard-widget.board_cover",
    [EMissionType.VORSATZ]: "dashboard-widget.board_vorsats"
};


;// CONCATENATED MODULE: ./src/shared/constant/index.ts




/***/ }),

/***/ 8718:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "o": () => (/* reexport */ EStatus)
});

;// CONCATENATED MODULE: ./src/shared/enums/status.ts
var EStatus;
(function(EStatus) {
    EStatus[EStatus["NOT_YET"] = 1] = "NOT_YET";
    EStatus[EStatus["IN_PROCESS"] = 2] = "IN_PROCESS";
    EStatus[EStatus["DONE"] = 3] = "DONE";
    EStatus[EStatus["FAULT"] = 4] = "FAULT";
    EStatus[EStatus["WAITING"] = 5] = "WAITING";
})(EStatus || (EStatus = {}));

;// CONCATENATED MODULE: ./src/shared/enums/index.ts


;// CONCATENATED MODULE: ./src/shared/index.ts




/***/ }),

/***/ 1212:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ agentsState)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const agentsState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "agentsState",
    default: []
});



/***/ }),

/***/ 8067:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ boardsMissionsStatusFilterState)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const boardsMissionsStatusFilterState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "boards-filter",
    default: null
});


/***/ }),

/***/ 9462:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ clientsState)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const clientsState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "clientsState",
    default: []
});



/***/ }),

/***/ 229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "FW": () => (/* reexport */ DashboardActions),
  "vi": () => (/* reexport */ adminState),
  "Di": () => (/* reexport */ dashboardDateState),
  "ey": () => (/* reexport */ permissions/* permissionsState */.e),
  "XG": () => (/* reexport */ themeState),
  "KL": () => (/* reexport */ userState)
});

// UNUSED EXPORTS: storeNameState

// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(9755);
;// CONCATENATED MODULE: ./src/store/store-name.ts

const storeNameState = (0,external_recoil_.atom)({
    key: "storeNameState",
    default: "defaultValue"
}); // const setStoreNameValue = useSetRecoilState(storeNameState)
 // const storeNameValue = useRecoilValue(storeNameState)
 // const [storeNameValue,setStoreNameValue] = useRecoilState(storeNameState)

;// CONCATENATED MODULE: ./src/utils/default-theme.ts
const defaultTheme = {
    themeMode: "light",
    primary: {
        light: {
            500: "#2E3092",
            400: "#5859A8",
            300: "#8283BE",
            200: "#ABACD3",
            100: "#D5D6E9"
        },
        dark: {
            500: "#2E3092",
            600: "#252675",
            700: "#1C1D58",
            800: "#12133A",
            900: "#090A1D"
        }
    },
    second: {
        light: {
            500: "#ED028C",
            400: "#F135A3",
            300: "#F467BA",
            200: "#F89AD1",
            100: "#FBCCE8"
        },
        dark: {
            500: "#ED028C",
            600: "#BE0270",
            700: "#8E0154",
            800: "#5F0138",
            900: "#2F001C"
        }
    },
    success: {
        light: {
            500: "#40CC4E",
            400: "#66D671",
            300: "#8CE095",
            200: "#B3EBB8",
            100: "#D9F5DC"
        },
        dark: {
            500: "#40CC4E",
            600: "#33A33E",
            700: "#267A2F",
            800: "#1A521F",
            900: "#0D2910"
        }
    },
    warning: {
        light: {
            500: "#ECBD17",
            400: "#F0CA45",
            300: "#F4D774",
            200: "#F7E5A2",
            100: "#FBF2D1"
        },
        dark: {
            500: "#ECBD17",
            600: "#BD9712",
            700: "#8E710E",
            800: "#5E4C09",
            900: "#2F2605"
        }
    },
    error: {
        light: {
            500: "#D92C2C",
            400: "#E15656",
            300: "#E88080",
            200: "#F0ABAB",
            100: "#F7D5D5"
        },
        dark: {
            500: "#D92C2C",
            600: "#AE2323",
            700: "#821A1A",
            800: "#571212",
            900: "#2B0909"
        }
    },
    neutral: {
        light: {
            500: "#9E9E9E",
            400: "#B1B1B1",
            300: "#C5C5C5",
            200: "#D8D8D8",
            100: "#ECECEC"
        },
        dark: {
            500: "#9E9E9E",
            600: "#7E7E7E",
            700: "#5F5F5F",
            800: "#3F3F3F",
            900: "#202020"
        }
    }
};

;// CONCATENATED MODULE: ./src/store/theme.ts


const themeState = (0,external_recoil_.atom)({
    key: "themeState",
    default: defaultTheme
});
 // export interface ITheme {
 //   primary: {
 //     light: {
 //       500: string;
 //       400: string;
 //       300: string;
 //       200: string;
 //       100: string;
 //     };
 //     dark: {
 //       500: string;
 //       600: string;
 //       700: string;
 //       800: string;
 //       900: string;
 //     };
 //   };
 //   second: {
 //     light: {
 //       500: string;
 //       400: string;
 //       300: string;
 //       200: string;
 //       100: string;
 //     };
 //     dark: {
 //       500: string;
 //       600: string;
 //       700: string;
 //       800: string;
 //       900: string;
 //     };
 //   };
 //   success: {
 //     light: {
 //       500: string;
 //       400: string;
 //       300: string;
 //       200: string;
 //       100: string;
 //     };
 //     dark: {
 //       500: string;
 //       600: string;
 //       700: string;
 //       800: string;
 //       900: string;
 //     };
 //   };
 //   warning: {
 //     light: {
 //       500: string;
 //       400: string;
 //       300: string;
 //       200: string;
 //       100: string;
 //     };
 //     dark: {
 //       500: string;
 //       600: string;
 //       700: string;
 //       800: string;
 //       900: string;
 //     };
 //   };
 //   error: {
 //     light: {
 //       500: string;
 //       400: string;
 //       300: string;
 //       200: string;
 //       100: string;
 //     };
 //     dark: {
 //       500: string;
 //       600: string;
 //       700: string;
 //       800: string;
 //       900: string;
 //     };
 //   };
 //   neutral: {
 //     light: {
 //       500: string;
 //       400: string;
 //       300: string;
 //       200: string;
 //       100: string;
 //     };
 //     dark: {
 //       500: string;
 //       600: string;
 //       700: string;
 //       800: string;
 //       900: string;
 //     };
 //   };
 // }

;// CONCATENATED MODULE: ./src/store/user.ts

const userState = (0,external_recoil_.atom)({
    key: "userState",
    default: {}
});

;// CONCATENATED MODULE: ./src/store/admin.ts

const adminState = (0,external_recoil_.atom)({
    key: "adminState",
    default: {}
});

// EXTERNAL MODULE: ./src/store/permissions.ts
var permissions = __webpack_require__(3360);
// EXTERNAL MODULE: ./src/shared/constant/index.ts + 3 modules
var constant = __webpack_require__(6057);
;// CONCATENATED MODULE: ./src/store/dashboard-date.ts


var DashboardActions;
(function(DashboardActions) {
    DashboardActions[DashboardActions["ALL_BOARDS_MISSIONS"] = 0] = "ALL_BOARDS_MISSIONS";
    DashboardActions[DashboardActions["LATE_TODAY_BOARDS_MISSIONS"] = 1] = "LATE_TODAY_BOARDS_MISSIONS";
    DashboardActions[DashboardActions["LATE_BOARDS_MISSIONS"] = 2] = "LATE_BOARDS_MISSIONS";
    DashboardActions[DashboardActions["TODAY_BOARDS_MISSIONS"] = 3] = "TODAY_BOARDS_MISSIONS";
    DashboardActions[DashboardActions["TOMORROW_BOARDS_MISSIONS"] = 4] = "TOMORROW_BOARDS_MISSIONS";
    DashboardActions[DashboardActions["DATE_RANGE_BOARDS"] = 5] = "DATE_RANGE_BOARDS";
})(DashboardActions || (DashboardActions = {}));
const dashboardDateState = (0,external_recoil_.atom)({
    key: "dashboardSelectedDate",
    default: {
        dates: {
            startDate: undefined,
            endDate: constant/* TODAY_DATE_RANGE.startDate */.Bz.startDate
        },
        action: DashboardActions.LATE_TODAY_BOARDS_MISSIONS
    }
});


;// CONCATENATED MODULE: ./src/store/index.ts








/***/ }),

/***/ 8072:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ loadgingState)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const loadgingState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "losadingState-1",
    default: false
});


/***/ }),

/***/ 5796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ machinesListState)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const machinesListState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "machinesState",
    default: []
});


/***/ }),

/***/ 3360:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ permissionsState)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const permissionsState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "permissionsState",
    default: {}
});


/***/ }),

/***/ 4680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ FONT_FAMILY)
/* harmony export */ });
const FONT_FAMILY = {
    Outfit: (fontWeight, fontSize)=>{
        return {
            fontFamily: "Outfit",
            fontWeight,
            fontSize
        };
    },
    Lexend: (fontWeight, fontSize)=>{
        return {
            fontFamily: "Lexend",
            fontWeight,
            fontSize
        };
    },
    Inter: (fontWeight, fontSize)=>{
        return {
            fontFamily: "Inter",
            fontWeight,
            fontSize
        };
    },
    Poppins: (fontWeight, fontSize)=>{
        return {
            fontFamily: "Poppins",
            fontWeight,
            fontSize
        };
    },
    Heebo: (fontWeight, fontSize)=>{
        return {
            fontFamily: "Heebo",
            fontWeight,
            fontSize
        };
    }
};



/***/ }),

/***/ 4826:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* reexport safe */ _login__WEBPACK_IMPORTED_MODULE_0__.s)
/* harmony export */ });
/* harmony import */ var _login__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4284);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_login__WEBPACK_IMPORTED_MODULE_0__]);
_login__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5362:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ InputContainer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1412);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3810);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const InputContainer = ({ input , error , changeState  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_3__/* .useStyle */ .X)();
    const onChangeState = (e)=>{
        changeState(input.key, e.target.value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: clasess.inputContainer,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.inputLbl,
                children: t(input.label)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.input,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .GomakeTextInput */ .Jw, {
                    onChange: onChangeState,
                    type: input.type,
                    error: error
                })
            })
        ]
    }, input.key);
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1622:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ LoginLeftSide)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1412);
/* harmony import */ var _use_login__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9206);
/* harmony import */ var _input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5362);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3810);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_use_login__WEBPACK_IMPORTED_MODULE_2__, _input__WEBPACK_IMPORTED_MODULE_3__]);
([_use_login__WEBPACK_IMPORTED_MODULE_2__, _input__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const LoginLeftSide = ()=>{
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_4__/* .useStyle */ .X)();
    const { errors , inputs , changeState , onClickLogin  } = (0,_use_login__WEBPACK_IMPORTED_MODULE_2__/* .useGomakeAdminLogin */ .f)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: clasess.leftContainer,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: clasess.loginContainer,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.loginLbl,
                        children: "Login"
                    }),
                    inputs.map((input)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_input__WEBPACK_IMPORTED_MODULE_3__/* .InputContainer */ .f, {
                            input: input,
                            changeState: changeState,
                            error: errors[input.key]
                        }, input.key))
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.btnContainer,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .GomakePrimaryButton */ .tm, {
                    onClick: onClickLogin,
                    children: "Login"
                })
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3254);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const useStyle = ()=>{
    const { theme , primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeTheme */ .G)();
    const clasess = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return {
            leftContainer: {
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                flex: 0.5,
                height: "100vh"
            },
            logoContainer: {
                marginTop: 100,
                marginBottom: 100,
                display: "flex"
            },
            loginContainer: {
                alignItems: "flex-start",
                width: "100%",
                paddingLeft: 48
            },
            loginLbl: {
                color: primaryColor(600),
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Outfit */ .u.Outfit(600, 48),
                marginBottom: 40
            },
            inputContainer: {
                display: "flex",
                flexDirection: "column",
                gap: 16,
                marginTop: 40
            },
            inputLbl: {
                color: primaryColor(900),
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(600, 20)
            },
            input: {
                width: "87%"
            },
            btnContainer: {
                width: "53%",
                marginTop: 62
            }
        };
    }, [
        theme
    ]);
    return {
        clasess
    };
};



/***/ }),

/***/ 4284:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ AdminLoginWidget)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _left_side_left_side__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1622);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2679);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_left_side_left_side__WEBPACK_IMPORTED_MODULE_1__]);
_left_side_left_side__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const AdminLoginWidget = ()=>{
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_2__/* .useStyle */ .X)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: clasess.container,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_left_side_left_side__WEBPACK_IMPORTED_MODULE_1__/* .LoginLeftSide */ .s, {})
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2679:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3254);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const useStyle = ()=>{
    const { theme , primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeTheme */ .G)();
    const clasess = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return {
            container: {
                backgroundColor: "#FFFFFF",
                flex: 1,
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                height: "100vh"
            }
        };
    }, [
        theme
    ]);
    return {
        clasess
    };
};



/***/ }),

/***/ 9206:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ useGomakeAdminLogin)
/* harmony export */ });
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6183);
/* harmony import */ var _services_storage_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3443);
/* harmony import */ var _store_loading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8072);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_0__]);
_hooks__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





// import { useTranslation } from "react-i18next";
const useGomakeAdminLogin = ()=>{
    // const { t } = useTranslation();
    const { callApi  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeAxios */ .S2)();
    const { navigate  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeRouter */ .VS)();
    const setLoadingState = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useSetRecoilState)(_store_loading__WEBPACK_IMPORTED_MODULE_2__/* .loadgingState */ .y);
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({});
    const [errors, setErrors] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        username: false,
        password: false
    });
    const changeState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((key, value)=>{
        setState({
            ...state,
            [key]: value
        });
    }, [
        state
    ]);
    const onClickLogin = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(async ()=>{
        const result = await callApi("POST", "/v1/admin/login-admin", {
            email: state.email,
            password: state.password
        });
        if (result?.data?.data?.token) {
            (0,_services_storage_data__WEBPACK_IMPORTED_MODULE_1__/* .updateTokenStorage */ .Yr)(result?.data?.data?.token);
            navigate("/admin");
        }
    }, [
        state
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        console.log(state);
    }, [
        state
    ]);
    const inputs = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return [
            {
                name: "email",
                label: "login.email",
                type: "text",
                placeholder: "login.email",
                required: true,
                key: "email"
            },
            {
                name: "password",
                label: "login.password",
                type: "password",
                placeholder: "Password",
                required: true,
                key: "password"
            }
        ];
    }, []);
    return {
        inputs,
        errors,
        changeState,
        onClickLogin
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3696:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AgentsList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3254);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _widgets_agents_state_selected_agent_id__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6974);
/* harmony import */ var _store_agents_state__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1212);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_6__]);
([_hooks__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Input = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_7__.styled)((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_5___default()))(()=>{
    const { primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_8__/* .useGomakeTheme */ .G)();
    return {
        input: {
            backgroundColor: "#FFFFFF",
            boxSizing: "border-box",
            borderRadius: "10px",
            fontFamily: "Jost",
            fontStyle: "normal",
            fontWeight: 300,
            fontSize: 14,
            lineHeight: "21px",
            display: "flex",
            alignItems: "center",
            width: "100%",
            color: primaryColor(500)
        },
        "& .MuiOutlinedInput-root": {
            "&:hover fieldset": {
                border: `2px solid ${primaryColor(500)}`
            },
            "& fieldset": {
                border: `1px solid ${primaryColor(500)}`,
                boxSizing: "border-box",
                borderRadius: 10,
                width: "100%"
            },
            "&.Mui-focused fieldset": {
                borderColor: primaryColor(500),
                borderRadius: 10,
                width: "100%"
            }
        },
        "& .MuiInputBase-root": {
            height: 40
        }
    };
});
const AutoSearch = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_7__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Autocomplete)(()=>{
    return {
        "& .MuiAutocomplete-root,": {
            width: "200px",
            border: 0
        }
    };
});
const AgentsList = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const { callApi  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useGomakeAxios */ .S2)();
    const setAgents = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useSetRecoilState)(_store_agents_state__WEBPACK_IMPORTED_MODULE_11__/* .agentsState */ .T);
    const agents = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilValue)(_store_agents_state__WEBPACK_IMPORTED_MODULE_11__/* .agentsState */ .T);
    const setSelectedAgentId = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useSetRecoilState)(_widgets_agents_state_selected_agent_id__WEBPACK_IMPORTED_MODULE_10__/* .selectedAgentIdState */ .z);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        callApi("GET", "/agents", {}, true, true).then((res)=>{
            if (res && res.success) {
                setAgents(res.data);
            }
        });
    }, []);
    const getClientsList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        return agents.map((agent)=>({
                label: agent.name,
                id: agent.id
            }));
    }, [
        agents
    ]);
    const handleChange = (event, value)=>{
        setSelectedAgentId(value?.id);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AutoSearch, {
            fullWidth: true,
            forcePopupIcon: false,
            onChange: handleChange,
            renderInput: (params)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                    sx: {
                        position: "relative"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Input, {
                            ...params,
                            placeholder: t("dashboard-widget.agents")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_9__.AccountCircle, {
                            sx: {
                                position: "absolute",
                                left: "5px",
                                top: "8px",
                                color: "action.active"
                            }
                        })
                    ]
                }),
            options: getClientsList()
        })
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6974:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ selectedAgentIdState)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const selectedAgentIdState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "selectedAgentIdState",
    default: ""
});



/***/ }),

/***/ 175:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ ClientsList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_clients_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9462);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _widgets_clients_state_selected_client_id__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6103);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7987);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3254);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_8__]);
([_hooks__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Input = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_9__.styled)((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6___default()))(()=>{
    const { primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_10__/* .useGomakeTheme */ .G)();
    return {
        input: {
            backgroundColor: "#FFFFFF",
            boxSizing: "border-box",
            borderRadius: "10px",
            fontFamily: "Jost",
            fontStyle: "normal",
            fontWeight: 300,
            fontSize: 14,
            lineHeight: "21px",
            display: "flex",
            alignItems: "center",
            width: "100%",
            color: primaryColor(500)
        },
        "& .MuiOutlinedInput-root": {
            "&:hover fieldset": {
                border: `2px solid ${primaryColor(500)}`
            },
            "& fieldset": {
                border: `1px solid ${primaryColor(500)}`,
                boxSizing: "border-box",
                borderRadius: 10,
                width: "100%"
            },
            "&.Mui-focused fieldset": {
                borderColor: primaryColor(500),
                borderRadius: 10,
                width: "100%"
            }
        },
        "& .MuiInputBase-root": {
            height: 40
        }
    };
});
const AutoSearch = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_9__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Autocomplete)(()=>{
    return {
        "& .MuiAutocomplete-root,": {
            width: "200px",
            border: 0
        }
    };
});
const ClientsList = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)();
    const { callApi  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useGomakeAxios */ .S2)();
    const setClients = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useSetRecoilState)(_store_clients_state__WEBPACK_IMPORTED_MODULE_4__/* .clientsState */ .D);
    const clients = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilValue)(_store_clients_state__WEBPACK_IMPORTED_MODULE_4__/* .clientsState */ .D);
    const setSelectedClientId = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useSetRecoilState)(_widgets_clients_state_selected_client_id__WEBPACK_IMPORTED_MODULE_7__/* .selectedClientIdState */ .S);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        callApi("GET", "/clients", {}, true, true).then((res)=>{
            if (res && res.success) {
                setClients(res.data);
            }
        });
    }, []);
    const getClientsList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        return clients.map((client)=>({
                label: client.code + " - " + client.name,
                id: client.id
            }));
    }, [
        clients
    ]);
    const handleChange = (event, value)=>{
        setSelectedClientId(value?.id);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AutoSearch, {
            fullWidth: true,
            forcePopupIcon: false,
            onChange: handleChange,
            renderInput: (params)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
                    sx: {
                        position: "relative"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Input, {
                            ...params,
                            placeholder: t("dashboard-widget.clients")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_11__.AccountCircle, {
                            sx: {
                                position: "absolute",
                                left: "5px",
                                top: "8px",
                                color: "action.active"
                            }
                        })
                    ]
                }),
            options: getClientsList()
        })
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6103:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ selectedClientIdState)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const selectedClientIdState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "selectedClientIdState",
    default: ""
});



/***/ }),

/***/ 3368:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ Cards)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_dashboard_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5179);
/* harmony import */ var _widgets_dashboard_widget_cards_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9073);
/* harmony import */ var _mui_icons_material_AddTask__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9560);
/* harmony import */ var _mui_icons_material_AddTask__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddTask__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_DoNotDisturbOnOutlined__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8088);
/* harmony import */ var _mui_icons_material_DoNotDisturbOnOutlined__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DoNotDisturbOnOutlined__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_LocalPrintshopOutlined__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1347);
/* harmony import */ var _mui_icons_material_LocalPrintshopOutlined__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocalPrintshopOutlined__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_FactCheckOutlined__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6117);
/* harmony import */ var _mui_icons_material_FactCheckOutlined__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FactCheckOutlined__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_AssignmentTurnedInOutlined__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8358);
/* harmony import */ var _mui_icons_material_AssignmentTurnedInOutlined__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AssignmentTurnedInOutlined__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_HourglassTop__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(960);
/* harmony import */ var _mui_icons_material_HourglassTop__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HourglassTop__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3254);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6183);
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8718);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_dashboard_card__WEBPACK_IMPORTED_MODULE_1__, _hooks__WEBPACK_IMPORTED_MODULE_10__]);
([_components_dashboard_card__WEBPACK_IMPORTED_MODULE_1__, _hooks__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Cards = ({ data  })=>{
    const { classes  } = (0,_widgets_dashboard_widget_cards_style__WEBPACK_IMPORTED_MODULE_2__/* .useStyle */ .X)();
    const { successColor , warningColor , errorColor , secondColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_9__/* .useGomakeTheme */ .G)();
    const { selectedDateText  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_10__/* .useGomakeDateRange */ .pb)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: classes.container,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                style: classes.header,
                children: selectedDateText()
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: classes.statistics,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_card__WEBPACK_IMPORTED_MODULE_1__/* .DashboardCard */ .I, {
                        label: data?.progress?.labelTranslationKey || "",
                        value: data?.inProcess?.value + data?.done?.value + data?.faults?.value + data?.waiting?.value || 0,
                        progressValue: data?.progress?.value * 100 || 0,
                        bgColor: "#9747FF",
                        withProgressBar: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FactCheckOutlined__WEBPACK_IMPORTED_MODULE_6___default()), {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_card__WEBPACK_IMPORTED_MODULE_1__/* .DashboardCard */ .I, {
                        label: data?.new?.labelTranslationKey || "",
                        value: data?.new?.value || 0,
                        bgColor: "#3DB2F9",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddTask__WEBPACK_IMPORTED_MODULE_3___default()), {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_card__WEBPACK_IMPORTED_MODULE_1__/* .DashboardCard */ .I, {
                        label: data?.done?.labelTranslationKey || "",
                        value: data?.done?.value || 0,
                        status: _shared__WEBPACK_IMPORTED_MODULE_11__/* .EStatus.DONE */ .o.DONE,
                        bgColor: successColor(500),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AssignmentTurnedInOutlined__WEBPACK_IMPORTED_MODULE_7___default()), {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_card__WEBPACK_IMPORTED_MODULE_1__/* .DashboardCard */ .I, {
                        label: data?.inProcess?.labelTranslationKey || "",
                        value: data?.inProcess?.value || 0,
                        status: _shared__WEBPACK_IMPORTED_MODULE_11__/* .EStatus.IN_PROCESS */ .o.IN_PROCESS,
                        bgColor: warningColor(500),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_LocalPrintshopOutlined__WEBPACK_IMPORTED_MODULE_5___default()), {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_card__WEBPACK_IMPORTED_MODULE_1__/* .DashboardCard */ .I, {
                        label: data?.waiting?.labelTranslationKey || "",
                        value: data?.waiting?.value || 0,
                        status: _shared__WEBPACK_IMPORTED_MODULE_11__/* .EStatus.WAITING */ .o.WAITING,
                        bgColor: secondColor(300),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_HourglassTop__WEBPACK_IMPORTED_MODULE_8___default()), {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_card__WEBPACK_IMPORTED_MODULE_1__/* .DashboardCard */ .I, {
                        label: data?.faults?.labelTranslationKey || "",
                        value: data?.faults?.value || 0,
                        status: _shared__WEBPACK_IMPORTED_MODULE_11__/* .EStatus.FAULT */ .o.FAULT,
                        bgColor: errorColor(500),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_DoNotDisturbOnOutlined__WEBPACK_IMPORTED_MODULE_4___default()), {})
                    })
                ]
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9073:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3254);



const useStyle = ()=>{
    const { theme , primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__/* .useGomakeTheme */ .G)();
    const classes = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return {
            container: {
                padding: "24px 21px 24px 32px",
                backgroundColor: "#fff",
                boxShadow: "0px 4px 20px rgba(238, 238, 238, 0.501967)",
                borderRadius: "20px",
                border: "1px solid #F8F9FA"
            },
            statistics: {
                display: "flex",
                justifyContent: "space-between",
                gap: "32px",
                height: "184px"
            },
            header: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Poppins */ .u.Poppins(600, 20),
                color: primaryColor(900),
                marginBottom: "20px"
            }
        };
    }, [
        theme
    ]);
    return {
        classes
    };
};



/***/ }),

/***/ 3594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ LateMissionsButton)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4680);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3254);




const LateMissionsButton = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default()))((props)=>{
    const { errorColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_3__/* .useGomakeTheme */ .G)();
    return {
        boxShadow: "none",
        textTransform: "none",
        padding: "14px",
        lineHeight: 1.5,
        backgroundColor: props.selected ? errorColor(500) : "#FFFFFF",
        border: `1px solid ${errorColor(500)}`,
        gap: 7,
        color: props.selected ? "#FFFFFF" : errorColor(500),
        width: "134px",
        height: "40px",
        borderColor: errorColor(500),
        borderRadius: "10px",
        "&:hover": {
            letterSpacing: "0.1em",
            backgroundColor: props.selected ? errorColor(500) : "#FFFFFF"
        },
        transition: "0.25s",
        ..._utils_font_family__WEBPACK_IMPORTED_MODULE_2__/* .FONT_FAMILY.Lexend */ .u.Lexend(500, 16)
    };
});



/***/ }),

/***/ 3945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ SearchInput)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3254);



const SearchInput = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_1___default()))(()=>{
    const { primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__/* .useGomakeTheme */ .G)();
    return {
        input: {
            backgroundColor: "#FFFFFF",
            boxSizing: "border-box",
            borderRadius: "10px",
            height: 40,
            fontFamily: "Jost",
            fontStyle: "normal",
            fontWeight: 300,
            fontSize: 14,
            lineHeight: "21px",
            display: "flex",
            alignItems: "center",
            color: primaryColor(500),
            minWidth: "150px"
        },
        "& .MuiOutlinedInput-root": {
            "&:hover fieldset": {
                border: `2px solid ${primaryColor(500)}`
            },
            "& fieldset": {
                border: `1px solid ${primaryColor(500)}`,
                boxSizing: "border-box",
                borderRadius: 10,
                width: "100%"
            },
            "&.Mui-focused fieldset": {
                borderColor: primaryColor(500),
                borderRadius: 10,
                width: "100%"
            }
        }
    };
});


/***/ }),

/***/ 9647:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DashboardWidget)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _widgets_dashboard_widget_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1924);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _widgets_dashboard_widget_cards_cards__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3368);
/* harmony import */ var _widgets_dashboard_widget_table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2870);
/* harmony import */ var _widgets_dashboard_widget_dates_dates__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5975);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6183);
/* harmony import */ var _widgets_dashboard_widget_use_board_missions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6418);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7987);
/* harmony import */ var _widgets_clients_clients_list__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(175);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _widgets_clients_state_selected_client_id__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6103);
/* harmony import */ var _widgets_dashboard_widget_components_search_input__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3945);
/* harmony import */ var _store_clients_state__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9462);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _hooks_use_dashboard_logout__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9416);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3254);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(229);
/* harmony import */ var _widgets_agents_agents_list__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3696);
/* harmony import */ var _widgets_agents_state_selected_agent_id__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(6974);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_widgets_dashboard_widget_cards_cards__WEBPACK_IMPORTED_MODULE_3__, _widgets_dashboard_widget_table__WEBPACK_IMPORTED_MODULE_4__, _widgets_dashboard_widget_dates_dates__WEBPACK_IMPORTED_MODULE_5__, _hooks__WEBPACK_IMPORTED_MODULE_6__, _widgets_dashboard_widget_use_board_missions__WEBPACK_IMPORTED_MODULE_7__, react_i18next__WEBPACK_IMPORTED_MODULE_8__, _widgets_clients_clients_list__WEBPACK_IMPORTED_MODULE_9__, _widgets_agents_agents_list__WEBPACK_IMPORTED_MODULE_20__]);
([_widgets_dashboard_widget_cards_cards__WEBPACK_IMPORTED_MODULE_3__, _widgets_dashboard_widget_table__WEBPACK_IMPORTED_MODULE_4__, _widgets_dashboard_widget_dates_dates__WEBPACK_IMPORTED_MODULE_5__, _hooks__WEBPACK_IMPORTED_MODULE_6__, _widgets_dashboard_widget_use_board_missions__WEBPACK_IMPORTED_MODULE_7__, react_i18next__WEBPACK_IMPORTED_MODULE_8__, _widgets_clients_clients_list__WEBPACK_IMPORTED_MODULE_9__, _widgets_agents_agents_list__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















const DashboardWidget = ({})=>{
    const INTERVAL_TIMEOUT = 2 * 60 * 1000;
    const { machines , addMachineProgress , getCheckedMachines  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGomakeMachines */ .gB)();
    const [tasksFilter, setTasksFilter] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const selectedClient = (0,recoil__WEBPACK_IMPORTED_MODULE_10__.useRecoilValue)(_widgets_clients_state_selected_client_id__WEBPACK_IMPORTED_MODULE_11__/* .selectedClientIdState */ .S);
    const selectedAgent = (0,recoil__WEBPACK_IMPORTED_MODULE_10__.useRecoilValue)(_widgets_agents_state_selected_agent_id__WEBPACK_IMPORTED_MODULE_21__/* .selectedAgentIdState */ .z);
    const clients = (0,recoil__WEBPACK_IMPORTED_MODULE_10__.useRecoilValue)(_store_clients_state__WEBPACK_IMPORTED_MODULE_13__/* .clientsState */ .D);
    const { classes  } = (0,_widgets_dashboard_widget_style__WEBPACK_IMPORTED_MODULE_1__/* .useStyle */ .X)();
    const { dates , action  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGomakeDateRange */ .pb)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)();
    const { secondColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_18__/* .useGomakeTheme */ .G)();
    const { logout  } = (0,_hooks_use_dashboard_logout__WEBPACK_IMPORTED_MODULE_17__/* .useDashboardLogout */ .Z)();
    const { getBoardsMissionsByDateRange , statistics , machinesProgress , boardsMissions , getFilteredBoardsMissions , getLateBoardsMissions , getLateTodayBoardsMissions , getAllBoardsMissions  } = (0,_widgets_dashboard_widget_use_board_missions__WEBPACK_IMPORTED_MODULE_7__/* .useBoardMissions */ .W)();
    const actions = (action, dateRange)=>{
        switch(action){
            case _store__WEBPACK_IMPORTED_MODULE_19__/* .DashboardActions.LATE_TODAY_BOARDS_MISSIONS */ .FW.LATE_TODAY_BOARDS_MISSIONS:
                getLateTodayBoardsMissions().then();
                break;
            case _store__WEBPACK_IMPORTED_MODULE_19__/* .DashboardActions.LATE_BOARDS_MISSIONS */ .FW.LATE_BOARDS_MISSIONS:
                getLateBoardsMissions().then();
                break;
            case _store__WEBPACK_IMPORTED_MODULE_19__/* .DashboardActions.ALL_BOARDS_MISSIONS */ .FW.ALL_BOARDS_MISSIONS:
                getAllBoardsMissions().then();
                break;
            default:
                getBoardsMissionsByDateRange(dateRange).then();
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        actions(action, dates);
    }, [
        action,
        dates
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        addMachineProgress(machinesProgress);
    }, [
        boardsMissions
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const interval = setInterval(async ()=>{
            actions(action, dates);
        }, INTERVAL_TIMEOUT);
        return ()=>clearInterval(interval);
    }, [
        dates,
        action
    ]);
    const handelSearchValueChange = (event)=>{
        const { value  } = event.target;
        setTasksFilter(value);
    };
    const usedMachines = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        return getCheckedMachines().filter((machine)=>{
            for (const board of getFilteredBoardsMissions()){
                if (board.machinesStatuses[machine.id]) {
                    return true;
                }
            }
            return false;
        });
    }, [
        machines
    ]);
    const tasks = (0,react__WEBPACK_IMPORTED_MODULE_2__.useCallback)(()=>{
        let tasksArray = getFilteredBoardsMissions().map((board)=>{
            if (clients.length > 0) {
                const client = clients.find((client)=>client.id === board.clientId);
                return {
                    ...board,
                    clientName: client?.name
                };
            }
            return board;
        });
        if (selectedClient) {
            tasksArray = tasksArray.filter((board)=>board.clientId === selectedClient);
        }
        if (selectedAgent) {
            tasksArray = tasksArray.filter((board)=>board.agentId === selectedAgent);
        }
        return tasksFilter ? tasksArray.filter((boardsMissions)=>{
            return boardsMissions.code.toLowerCase().includes(tasksFilter.toLowerCase()) || boardsMissions.orderNumber.toLowerCase().includes(tasksFilter.toLowerCase());
        }) : tasksArray;
    }, [
        tasksFilter,
        getFilteredBoardsMissions(),
        selectedClient,
        selectedAgent
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: classes.container,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets_dashboard_widget_cards_cards__WEBPACK_IMPORTED_MODULE_3__/* .Cards */ .o, {
                data: statistics ? statistics : {}
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets_dashboard_widget_dates_dates__WEBPACK_IMPORTED_MODULE_5__/* .DashboardDates */ .i, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    style: {
                        display: "flex",
                        gap: "16px",
                        width: "fit-content",
                        alignItems: "center"
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_14__.Box, {
                            sx: {
                                position: "relative"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets_dashboard_widget_components_search_input__WEBPACK_IMPORTED_MODULE_12__/* .SearchInput */ .M, {
                                    placeholder: t("dashboard-widget.search"),
                                    onChange: handelSearchValueChange
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    sx: {
                                        position: "absolute",
                                        left: "5px",
                                        top: "8px",
                                        color: "action.active"
                                    }
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets_clients_clients_list__WEBPACK_IMPORTED_MODULE_9__/* .ClientsList */ .y, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets_agents_agents_list__WEBPACK_IMPORTED_MODULE_20__/* .AgentsList */ .Z, {})
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: usedMachines() && getFilteredBoardsMissions() && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets_dashboard_widget_table__WEBPACK_IMPORTED_MODULE_4__/* .BoardMissionsTable */ .m, {
                    boardsMissions: tasks(),
                    usedMachines: usedMachines()
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_14__.Link, {
                    component: (_mui_material_Button__WEBPACK_IMPORTED_MODULE_16___default()),
                    color: secondColor(500),
                    onClick: logout,
                    children: t("dashboard-widget.logout")
                })
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5975:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ DashboardDates)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _widgets_dashboard_widget_dates_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1793);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1412);
/* harmony import */ var _widgets__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2565);
/* harmony import */ var _components_datepicker__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9262);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6183);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7987);
/* harmony import */ var _widgets_dashboard_widget_components_late_missions_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3594);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(229);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_widgets__WEBPACK_IMPORTED_MODULE_3__, _components_datepicker__WEBPACK_IMPORTED_MODULE_4__, _hooks__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_7__]);
([_widgets__WEBPACK_IMPORTED_MODULE_3__, _components_datepicker__WEBPACK_IMPORTED_MODULE_4__, _hooks__WEBPACK_IMPORTED_MODULE_6__, react_i18next__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const DashboardDates = ({ children  })=>{
    const { classes  } = (0,_widgets_dashboard_widget_dates_style__WEBPACK_IMPORTED_MODULE_1__/* .useStyle */ .X)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const { setTodayDateRange , setTomorrowDateRange , setLateToday , action , setLateBoardsMissions , setAllBoardsMissions  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useGomakeDateRange */ .pb)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: classes.container,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: classes.datesContainer,
                children: [
                    action === _store__WEBPACK_IMPORTED_MODULE_9__/* .DashboardActions.LATE_TODAY_BOARDS_MISSIONS */ .FW.LATE_TODAY_BOARDS_MISSIONS ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .GomakePrimaryButton */ .tm, {
                        style: classes.activeButton,
                        children: t("dashboard-widget.today") + " & " + t("dashboard-widget.lateMissions")
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_5___default()), {
                        variant: "outlined",
                        onClick: setLateToday,
                        style: classes.button,
                        children: t("dashboard-widget.today") + " & " + t("dashboard-widget.lateMissions")
                    }),
                    action === _store__WEBPACK_IMPORTED_MODULE_9__/* .DashboardActions.TODAY_BOARDS_MISSIONS */ .FW.TODAY_BOARDS_MISSIONS ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .GomakePrimaryButton */ .tm, {
                        style: classes.activeButton,
                        children: t("dashboard-widget.today")
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_5___default()), {
                        variant: "outlined",
                        onClick: ()=>setTodayDateRange(),
                        style: classes.button,
                        children: t("dashboard-widget.today")
                    }),
                    action === _store__WEBPACK_IMPORTED_MODULE_9__/* .DashboardActions.TOMORROW_BOARDS_MISSIONS */ .FW.TOMORROW_BOARDS_MISSIONS ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .GomakePrimaryButton */ .tm, {
                        style: classes.activeButton,
                        children: t("dashboard-widget.tomorrow")
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_5___default()), {
                        variant: "outlined",
                        onClick: ()=>setTomorrowDateRange(),
                        style: classes.button,
                        children: t("dashboard-widget.tomorrow")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets_dashboard_widget_components_late_missions_button__WEBPACK_IMPORTED_MODULE_8__/* .LateMissionsButton */ .$, {
                        onClick: setLateBoardsMissions,
                        selected: action === _store__WEBPACK_IMPORTED_MODULE_9__/* .DashboardActions.LATE_BOARDS_MISSIONS */ .FW.LATE_BOARDS_MISSIONS,
                        children: t("dashboard-widget.lateMissions")
                    }),
                    action === _store__WEBPACK_IMPORTED_MODULE_9__/* .DashboardActions.ALL_BOARDS_MISSIONS */ .FW.ALL_BOARDS_MISSIONS ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .GomakePrimaryButton */ .tm, {
                        style: classes.activeButton,
                        children: t("dashboard-widget.all")
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_5___default()), {
                        variant: "outlined",
                        onClick: setAllBoardsMissions,
                        style: classes.button,
                        children: t("dashboard-widget.all")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_datepicker__WEBPACK_IMPORTED_MODULE_4__/* .GoMakeDatepicker */ .G, {})
                ]
            }),
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: classes.machinesWrapper,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widgets__WEBPACK_IMPORTED_MODULE_3__/* .MachineList */ .C0, {})
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1793:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3254);



const useStyle = ()=>{
    const { theme , primaryColor , errorColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__/* .useGomakeTheme */ .G)();
    const classes = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return {
            container: {
                display: "flex",
                padding: "0 21px 0 32px",
                gap: "32px"
            },
            datesContainer: {
                display: "flex",
                gap: "16px"
            },
            button: {
                width: "fit-content",
                minWidth: "134px",
                height: "40px",
                borderRadius: "10px",
                color: primaryColor(500),
                borderColor: primaryColor(500),
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(500, 16)
            },
            lateButton: {
                width: "134px",
                height: "40px",
                borderRadius: "10px",
                color: errorColor(500),
                borderColor: errorColor(500),
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(500, 16)
            },
            activeButton: {
                width: "134px",
                height: "40px",
                borderColor: primaryColor(500),
                borderRadius: "10px"
            },
            machinesWrapper: {
                alignSelf: "flex-end",
                marginRight: "auto"
            }
        };
    }, [
        theme
    ]);
    return {
        classes
    };
};



/***/ }),

/***/ 3921:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* reexport safe */ _dashboard_widget__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var _dashboard_widget__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9647);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_dashboard_widget__WEBPACK_IMPORTED_MODULE_0__]);
_dashboard_widget__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useStyle = ()=>{
    const classes = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return {
            container: {
                display: "flex",
                flexDirection: "column",
                gap: "30px"
            }
        };
    }, []);
    return {
        classes
    };
};



/***/ }),

/***/ 2870:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* reexport safe */ _table__WEBPACK_IMPORTED_MODULE_0__.m)
/* harmony export */ });
/* harmony import */ var _table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3323);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_table__WEBPACK_IMPORTED_MODULE_0__]);
_table__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2936:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3254);



const useStyle = ()=>{
    const { theme , primaryColor , warningColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__/* .useGomakeTheme */ .G)();
    const BORDER = "0.1px solid #CECECE";
    const BORDER_RADIUS = "16px";
    const classes = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return {
            tableWrapper: {
                border: BORDER,
                borderRadius: BORDER_RADIUS,
                borderRight: 0,
                padding: 0,
                margin: "10px 21px 15px 21px",
                overflow: "overlay",
                width: "fit-content",
                maxHeight: "80vh",
                maxWidth: "96vw"
            },
            table: {
                borderCollapse: "collapse",
                position: "relative"
            },
            tableHead: {
                backgroundColor: primaryColor(500),
                minHeight: "80px",
                height: "80px",
                maxHeight: "80px",
                color: "white",
                textAlign: "center",
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(400, 16),
                padding: "10px",
                position: "sticky",
                top: "0px",
                cursor: "pointer"
            },
            selectedMachine: {
                backgroundColor: primaryColor(300)
            },
            tableCell: {
                textAlign: "center",
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(500, 16),
                lineHeight: 0,
                height: "40px",
                minWidth: "115px",
                border: BORDER,
                borderTop: 0,
                borderLeft: 0
            },
            tdRows: {
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                width: "100%",
                height: "100%",
                maxHeight: "80px",
                // gap: '10px',
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(400, 16)
            },
            firstColHead: {
                minWidth: "500px",
                right: 0,
                zIndex: 1,
                padding: "0 5px"
            },
            firstColHeadContent: {
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                borderRight: 0
            },
            firstColCell: {
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                minWidth: "350px",
                padding: " 5px"
            },
            splitBoardsStatuses: {
                display: "flex",
                flexDirection: "column",
                alignItems: "center"
            },
            splitBoardsStatusesRow: {
                height: 40,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: 10,
                width: 200,
                border: 0,
                paddingLeft: 5
            },
            firstColCellSplitBoards: {
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                minWidth: "405px",
                padding: "0 5px 0 0"
            },
            lateMission: {
                backgroundColor: warningColor(100)
            }
        };
    }, [
        theme
    ]);
    return {
        classes
    };
};



/***/ }),

/***/ 3323:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ BoardMissionsTable)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _widgets_dashboard_widget_table_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2936);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _components_status_view__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8686);
/* harmony import */ var _mui_icons_material_ElectricBoltSharp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4557);
/* harmony import */ var _mui_icons_material_ElectricBoltSharp__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ElectricBoltSharp__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _shared_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6057);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8718);
/* harmony import */ var _services_storage_data__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3443);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _store_boards_missions_status_filter__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8067);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _components_status_view__WEBPACK_IMPORTED_MODULE_3__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _components_status_view__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const BoardMissionsTable = ({ boardsMissions , usedMachines  })=>{
    const { classes  } = (0,_widgets_dashboard_widget_table_style__WEBPACK_IMPORTED_MODULE_1__/* .useStyle */ .X)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const [orderByMachine, setOrderByMachine] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const selectedStatusFilter = (0,recoil__WEBPACK_IMPORTED_MODULE_10__.useRecoilValue)(_store_boards_missions_status_filter__WEBPACK_IMPORTED_MODULE_11__/* .boardsMissionsStatusFilterState */ .C);
    const boardLink = (boardMissions)=>{
        const host = (0,_services_storage_data__WEBPACK_IMPORTED_MODULE_9__/* .getPrintHouseHost */ .z_)();
        return `https://${host}/Kanban/Board/${boardMissions.boardId}?missionId=${boardMissions.id}`;
    };
    const hasMachine = (board)=>{
        switch(board.machinesStatuses[orderByMachine]){
            case _shared__WEBPACK_IMPORTED_MODULE_8__/* .EStatus.IN_PROCESS */ .o.IN_PROCESS:
                return 0;
            case _shared__WEBPACK_IMPORTED_MODULE_8__/* .EStatus.WAITING */ .o.WAITING:
                return 1;
            case _shared__WEBPACK_IMPORTED_MODULE_8__/* .EStatus.FAULT */ .o.FAULT:
                return 2;
            case _shared__WEBPACK_IMPORTED_MODULE_8__/* .EStatus.NOT_YET */ .o.NOT_YET:
                return 3;
            case _shared__WEBPACK_IMPORTED_MODULE_8__/* .EStatus.DONE */ .o.DONE:
                return 4;
            default:
                return 5;
        }
    };
    const getFilteredBoardMissions = (selectedStatusFilter)=>{
        var data = [
            ...boardsMissions
        ];
        if (selectedStatusFilter) {
            data.forEach((x)=>{
                if (x.splittedBoards) {
                    x.splittedBoards = x.splittedBoards.filter((y)=>y.status === selectedStatusFilter);
                }
            });
            data = data.filter((board)=>board.status === selectedStatusFilter || board.splittedBoards && board.splittedBoards.length > 0);
        }
        return data;
    };
    const boards = (0,react__WEBPACK_IMPORTED_MODULE_7__.useCallback)(()=>{
        let boards = getFilteredBoardMissions(selectedStatusFilter) //littedBoards = x.splittedBoards.filter(y=>y.status == selectedStatusFilter) ).filter()] : [...boardsMissions];
        ;
        if (orderByMachine) {
            boards = boards.sort((board1, board2)=>{
                return hasMachine(board1) - hasMachine(board2);
            });
            return boards;
        }
        return boards;
    }, [
        orderByMachine,
        boardsMissions,
        selectedStatusFilter
    ]);
    const handleMachineClicked = (machineId)=>{
        setOrderByMachine(machineId === orderByMachine ? "" : machineId);
    };
    return boardsMissions.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: classes.tableWrapper,
        id: "dashboard-table",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
            style: classes.table,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                style: {
                                    ...classes.tableHead,
                                    ...classes.firstColHead
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    style: classes.firstColHeadContent,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                width: "5%"
                                            },
                                            children: "#"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                width: "5%"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                width: "30%"
                                            },
                                            children: t("dashboard-widget.client")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                width: "25%"
                                            },
                                            children: t("dashboard-widget.task")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                width: "20%"
                                            },
                                            children: t("dashboard-widget.product")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                width: "35%"
                                            },
                                            children: t("dashboard-widget.status")
                                        })
                                    ]
                                })
                            }),
                            usedMachines.map((machine)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    style: orderByMachine === machine.id ? {
                                        ...classes.tableHead,
                                        ...classes.selectedMachine
                                    } : classes.tableHead,
                                    onClick: ()=>handleMachineClicked(machine.id),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        style: classes.tdRows,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: machine.name
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    machine.progress?.done,
                                                    "/",
                                                    machine.progress?.total
                                                ]
                                            })
                                        ]
                                    })
                                }, machine.id);
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                    children: boards() && boards().map((board, index)=>{
                        return board.splittedBoards.length > 0 ? board.splittedBoards.map((splitBoard, k)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                style: board.isLate ? classes.lateMission : {},
                                children: [
                                    k === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        rowSpan: board.splittedBoards.length,
                                        style: {
                                            ...classes.tableCell,
                                            position: "sticky",
                                            right: 0,
                                            backgroundColor: board.isLate ? classes.lateMission.backgroundColor : "#FFFFFF"
                                        },
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            style: classes.firstColCellSplitBoards,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: {
                                                        width: "5%"
                                                    },
                                                    children: index + 1
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: {
                                                        width: "5%"
                                                    },
                                                    children: board.isUrgent ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ElectricBoltSharp__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        color: "error"
                                                    }) : ""
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: {
                                                        width: "30%"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: board?.clientName && board?.clientName?.length > 10 ? board.clientName?.slice(0, 9) + ".." : board?.clientName
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: {
                                                        width: "25%",
                                                        height: "100%"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        style: classes.tdRows,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: board.code
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: {
                                                        width: "20%",
                                                        height: "100%"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        style: classes.tdRows,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: board?.productName && board?.productName?.length > 8 ? board.productName?.slice(0, 7) + ".." : board?.productName
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: classes.splitBoardsStatuses,
                                                    children: board.splittedBoards.map((sBoard, cellNumber)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            style: cellNumber + 1 === board.splittedBoards.length ? {
                                                                ...classes.splitBoardsStatusesRow,
                                                                borderBottom: 0
                                                            } : classes.splitBoardsStatusesRow,
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Link, {
                                                                    href: boardLink(sBoard),
                                                                    target: "_blank",
                                                                    rel: "noopener",
                                                                    children: t(_shared_constant__WEBPACK_IMPORTED_MODULE_5__/* .TYPE_MISSION_NAME_KEY */ .cu[sBoard.missionType])
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_status_view__WEBPACK_IMPORTED_MODULE_3__/* .StatusView */ .l, {
                                                                    status: sBoard.status,
                                                                    label: sBoard.currentStation.rowName
                                                                })
                                                            ]
                                                        }))
                                                })
                                            ]
                                        })
                                    }),
                                    usedMachines.map((machine, i)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            style: k + 1 === board.splittedBoards.length ? classes.tableCell : {
                                                ...classes.tableCell,
                                                borderBottom: 0
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_status_view__WEBPACK_IMPORTED_MODULE_3__/* .StatusView */ .l, {
                                                style: {
                                                    margin: "auto"
                                                },
                                                status: splitBoard.machinesStatuses[machine.id]
                                            })
                                        }, machine.id + i);
                                    })
                                ]
                            });
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                            style: board.isLate ? classes.lateMission : {},
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                    style: {
                                        ...classes.tableCell,
                                        position: "sticky",
                                        right: 0,
                                        backgroundColor: board.isLate ? classes.lateMission.backgroundColor : "#FFFFFF"
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        style: classes.firstColCell,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "5%"
                                                },
                                                children: index + 1
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "5%"
                                                },
                                                children: board.isUrgent ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ElectricBoltSharp__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    color: "error"
                                                }) : ""
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "30%"
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: board?.clientName && board?.clientName?.length > 10 ? board.clientName?.slice(0, 9) + ".." : board?.clientName
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "25%",
                                                    height: "100%"
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: classes.tdRows,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Link, {
                                                            href: boardLink(board),
                                                            target: "_blank",
                                                            rel: "noopener",
                                                            children: board.code
                                                        })
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "20%",
                                                    height: "100%"
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: classes.tdRows,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: board?.productName && board?.productName?.length > 8 ? board.productName?.slice(0, 7) + ".." : board?.productName
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "35%"
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_status_view__WEBPACK_IMPORTED_MODULE_3__/* .StatusView */ .l, {
                                                    status: board.status,
                                                    style: {
                                                        margin: "auto",
                                                        marginLeft: 0
                                                    },
                                                    label: board.currentStation.rowName
                                                })
                                            })
                                        ]
                                    })
                                }),
                                usedMachines.map((machine, i)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        style: classes.tableCell,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_status_view__WEBPACK_IMPORTED_MODULE_3__/* .StatusView */ .l, {
                                            style: {
                                                margin: "auto"
                                            },
                                            status: board.machinesStatuses[machine.id]
                                        })
                                    }, machine.id + i);
                                })
                            ]
                        }, index);
                    })
                })
            ]
        })
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {});
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6418:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ useBoardMissions)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var _shared_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6057);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_1__]);
_hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const useBoardMissions = ()=>{
    const { machines , getCheckedMachines  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useGomakeMachines */ .gB)();
    const [boardsMissions, setBoardsMissions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [machinesProgress, setMachinesProgress] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [statistics, setStatistics] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { callApi  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useGomakeAxios */ .S2)();
    const getBoardsMissionsByDateRange = async (dateRange)=>{
        const res = await callApi("GET", "/boardMissions", {
            startDate: dateRange?.startDate?.toISOString(),
            endDate: dateRange?.endDate?.toISOString()
        }, true, true);
        setBoardsMissions(res?.data?.boardsMissions);
        setMachinesProgress(res?.data?.machinesProgress);
        setStatistics(res?.data?.statistics);
    };
    const getLateBoardsMissions = async ()=>{
        const res = await callApi("GET", "/lateBoardMissions", {}, true, true);
        setBoardsMissions(res?.data?.boardsMissions);
        setMachinesProgress(res?.data?.machinesProgress);
        setStatistics(res?.data?.statistics);
    };
    const getLateTodayBoardsMissions = async ()=>{
        const res = await callApi("GET", "/today-late-boardMissions", {
            startDate: _shared_constant__WEBPACK_IMPORTED_MODULE_2__/* .TODAY_DATE_RANGE.startDate */ .Bz.startDate?.toISOString(),
            endDate: _shared_constant__WEBPACK_IMPORTED_MODULE_2__/* .TODAY_DATE_RANGE.endDate */ .Bz.endDate?.toISOString()
        }, true, true);
        setBoardsMissions(res?.data?.boardsMissions);
        setMachinesProgress(res?.data?.machinesProgress);
        setStatistics(res?.data?.statistics);
    };
    const getAllBoardsMissions = async ()=>{
        const date = new Date();
        const year = date.getFullYear();
        const month = date.getMonth();
        const day = date.getDate();
        const nextYearDate = new Date(year + 1, month, day);
        const res = await callApi("GET", "/today-late-boardMissions", {
            startDate: _shared_constant__WEBPACK_IMPORTED_MODULE_2__/* .TODAY_DATE_RANGE.startDate */ .Bz.startDate?.toISOString(),
            endDate: (0,date_fns__WEBPACK_IMPORTED_MODULE_3__.endOfDay)(nextYearDate).toISOString()
        }, true, true);
        setBoardsMissions(res?.data?.boardsMissions);
        setMachinesProgress(res?.data?.machinesProgress);
        setStatistics(res?.data?.statistics);
    };
    const updateBoardMissions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((boards)=>{
        setBoardsMissions(boards);
    }, []);
    const getFilteredBoardsMissions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        let boards = boardsMissions;
        if (machinesProgress && boardsMissions) {
            boards = addCurrentMachineName(boards);
            boards = sortBoardMissionsByUrgent(boards);
            boards = sortBoardMissionsByReady(boards);
            boards = sortBoardMissionsByIsLate(boards);
        }
        return boards?.filter((boardMissions)=>{
            return getCheckedMachines().some((m)=>Object.keys(boardMissions.machinesStatuses).includes(m.id));
        });
    }, [
        boardsMissions,
        machinesProgress,
        machines
    ]);
    const sortBoardMissionsByUrgent = (boards)=>{
        return boards.sort((board1, board2)=>Number(board2.isUrgent) - Number(board1.isUrgent));
    };
    const sortBoardMissionsByReady = (boards)=>{
        return boards.sort((board1, board2)=>Number(board1.isReady) - Number(board2.isReady));
    };
    const sortBoardMissionsByIsLate = (boards)=>{
        return boards.sort((board1, board2)=>Number(board2.isLate) - Number(board1.isLate));
    };
    const addCurrentMachineName = (boards)=>{
        boards.forEach((board)=>{
            if (board.currentStation.machineId !== null) {
                const machine = machines.find((m)=>m.id === board.currentStation.machineId);
                if (machine) {
                    board.currentStation.rowName = machine.name;
                }
            }
            if (board.splittedBoards?.length > 0) {
                board.splittedBoards = addCurrentMachineName(board.splittedBoards);
            }
        });
        return boards;
    };
    const filterMachinesOfBoards = (machines, boards)=>{
        return machines.filter((machine)=>{
            for (const board of boards){
                if (board.machinesStatuses[machine.id]) {
                    return true;
                }
            }
            return false;
        });
    };
    return {
        statistics,
        getBoardsMissionsByDateRange,
        getLateBoardsMissions,
        filterMachinesOfBoards,
        updateBoardMissions,
        machinesProgress,
        getFilteredBoardsMissions,
        boardsMissions,
        getLateTodayBoardsMissions,
        getAllBoardsMissions
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2565:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C0": () => (/* reexport safe */ _machine_list__WEBPACK_IMPORTED_MODULE_5__.C),
/* harmony export */   "Up": () => (/* reexport safe */ _login__WEBPACK_IMPORTED_MODULE_2__.U),
/* harmony export */   "Xj": () => (/* reexport safe */ _loading__WEBPACK_IMPORTED_MODULE_3__.X),
/* harmony export */   "Zi": () => (/* reexport safe */ _dashboard_widget__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "hh": () => (/* reexport safe */ _widjet_name__WEBPACK_IMPORTED_MODULE_0__.h),
/* harmony export */   "s7": () => (/* reexport safe */ _admin_login__WEBPACK_IMPORTED_MODULE_4__.s),
/* harmony export */   "u2": () => (/* reexport safe */ _waiting_auth__WEBPACK_IMPORTED_MODULE_1__.u)
/* harmony export */ });
/* harmony import */ var _widjet_name__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2746);
/* harmony import */ var _waiting_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9721);
/* harmony import */ var _login__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5247);
/* harmony import */ var _loading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3418);
/* harmony import */ var _admin_login__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4826);
/* harmony import */ var _machine_list__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9085);
/* harmony import */ var _dashboard_widget__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3921);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_widjet_name__WEBPACK_IMPORTED_MODULE_0__, _login__WEBPACK_IMPORTED_MODULE_2__, _admin_login__WEBPACK_IMPORTED_MODULE_4__, _machine_list__WEBPACK_IMPORTED_MODULE_5__, _dashboard_widget__WEBPACK_IMPORTED_MODULE_6__]);
([_widjet_name__WEBPACK_IMPORTED_MODULE_0__, _login__WEBPACK_IMPORTED_MODULE_2__, _admin_login__WEBPACK_IMPORTED_MODULE_4__, _machine_list__WEBPACK_IMPORTED_MODULE_5__, _dashboard_widget__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "X": () => (/* reexport */ GomakeLoading)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(9755);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./src/widgets/waiting-auth/loading.json
var waiting_auth_loading = __webpack_require__(5686);
// EXTERNAL MODULE: ./src/store/loading.ts
var store_loading = __webpack_require__(8072);
;// CONCATENATED MODULE: ./src/widgets/loading/loading.tsx






const GomakeLoading = ()=>{
    const loading = (0,external_recoil_.useRecoilValue)(store_loading/* loadgingState */.y);
    const defaultOptions = {
        loop: true,
        autoplay: true,
        animationData: waiting_auth_loading,
        rendererSettings: {
            preserveAspectRatio: "xMidYMid slice"
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Backdrop, {
        style: {
            zIndex: 1
        },
        open: loading,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            style: {
                position: "absolute",
                bottom: 0,
                left: 0
            }
        })
    });
};


;// CONCATENATED MODULE: ./src/widgets/loading/index.tsx



/***/ }),

/***/ 5247:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* reexport safe */ _login__WEBPACK_IMPORTED_MODULE_0__.U)
/* harmony export */ });
/* harmony import */ var _login__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5865);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_login__WEBPACK_IMPORTED_MODULE_0__]);
_login__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9454:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ InputContainer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1412);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const InputContainer = ({ input , error , changeState  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_3__/* .useStyle */ .X)();
    const onChangeState = (e)=>{
        changeState(input.key, e.target.value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: clasess.inputContainer,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.inputLbl,
                children: t(input.label)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.input,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .GomakeTextInput */ .Jw, {
                    onChange: onChangeState,
                    type: input.type,
                    error: error
                })
            })
        ]
    }, input.key);
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9057:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ LoginLeftSide)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1412);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _use_login__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(789);
/* harmony import */ var _input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9454);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_use_login__WEBPACK_IMPORTED_MODULE_3__, _input__WEBPACK_IMPORTED_MODULE_4__]);
([_use_login__WEBPACK_IMPORTED_MODULE_3__, _input__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const LoginLeftSide = ()=>{
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_5__/* .useStyle */ .X)();
    const { errors , inputs , changeState , onClickLogin  } = (0,_use_login__WEBPACK_IMPORTED_MODULE_3__/* .useGomakeLogin */ .H)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: clasess.leftContainer,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.logoContainer,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: "https://i.ibb.co/wzpwSq6/Group-1239.png",
                    alt: "logo",
                    width: 100,
                    height: 100
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: clasess.loginContainer,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.loginLbl,
                        children: "Login"
                    }),
                    inputs.map((input)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_input__WEBPACK_IMPORTED_MODULE_4__/* .InputContainer */ .f, {
                            input: input,
                            changeState: changeState,
                            error: errors[input.key]
                        }, input.key))
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.btnContainer,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .GomakePrimaryButton */ .tm, {
                    onClick: onClickLogin,
                    children: "Login"
                })
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 45:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3254);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const useStyle = ()=>{
    const { theme , primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeTheme */ .G)();
    const clasess = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return {
            leftContainer: {
                display: "flex",
                flexDirection: "column",
                justifyContent: "flex-start",
                alignItems: "center",
                flex: 0.5,
                height: "100vh"
            },
            logoContainer: {
                marginTop: 100,
                marginBottom: 100,
                display: "flex"
            },
            loginContainer: {
                alignItems: "flex-start",
                width: "100%",
                paddingLeft: 48
            },
            loginLbl: {
                color: primaryColor(600),
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Outfit */ .u.Outfit(600, 48),
                marginBottom: 40
            },
            inputContainer: {
                display: "flex",
                flexDirection: "column",
                gap: 16,
                marginTop: 40
            },
            inputLbl: {
                color: primaryColor(900),
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(600, 20)
            },
            input: {
                width: "87%"
            },
            btnContainer: {
                width: "53%",
                marginTop: 62
            }
        };
    }, [
        theme
    ]);
    return {
        clasess
    };
};



/***/ }),

/***/ 5865:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ LoginWidget)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _left_side_left_side__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9057);
/* harmony import */ var _right_side_right_side__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4463);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8132);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_left_side_left_side__WEBPACK_IMPORTED_MODULE_1__, _right_side_right_side__WEBPACK_IMPORTED_MODULE_2__]);
([_left_side_left_side__WEBPACK_IMPORTED_MODULE_1__, _right_side_right_side__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const LoginWidget = ()=>{
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_3__/* .useStyle */ .X)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: clasess.container,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_left_side_left_side__WEBPACK_IMPORTED_MODULE_1__/* .LoginLeftSide */ .s, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_right_side_right_side__WEBPACK_IMPORTED_MODULE_2__/* .LoginRightSide */ .L, {})
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4463:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ LoginRightSide)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2457);
/* harmony import */ var _rocket_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1996);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
react_i18next__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const LoginRightSide = ()=>{
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_1__/* .useStyle */ .X)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: clasess.rightContainer,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.welcomeLbl,
                children: t("login.welcome")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: clasess.descriptionLbl,
                children: t("login.weAreExcited")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: _rocket_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                    alt: "gomake",
                    priority: true
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: clasess.poweredContainer,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.poweredByLbl,
                        children: t("login.poweredBy")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        style: clasess.gomakeByLbl,
                        children: t("login.GoMake")
                    })
                ]
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3254);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const useStyle = ()=>{
    const { theme , primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeTheme */ .G)();
    const clasess = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return {
            rightContainer: {
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                backgroundColor: "#504FA1",
                flex: 0.5,
                height: "100vh"
            },
            poweredContainer: {
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                marginTop: 53
            },
            poweredByLbl: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(400, 12),
                color: "#FFF"
            },
            gomakeByLbl: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(400, 28),
                color: "#FFF"
            },
            welcomeLbl: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Outfit */ .u.Outfit(600, 56),
                color: "#FFF",
                width: "50%",
                textAlign: "center",
                lineHeight: "71px"
            },
            descriptionLbl: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Outfit */ .u.Outfit(400, 16),
                color: "#FFF",
                width: "75%",
                textAlign: "center",
                marginTop: 20,
                marginBottom: 53,
                lineHeight: "20px"
            }
        };
    }, [
        theme
    ]);
    return {
        clasess
    };
};



/***/ }),

/***/ 8132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3254);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const useStyle = ()=>{
    const { theme , primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeTheme */ .G)();
    const clasess = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return {
            container: {
                backgroundColor: "#FFFFFF",
                flex: 1,
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                minHeight: "100vh"
            }
        };
    }, [
        theme
    ]);
    return {
        clasess
    };
};



/***/ }),

/***/ 789:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ useGomakeLogin)
/* harmony export */ });
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6183);
/* harmony import */ var _services_storage_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3443);
/* harmony import */ var _store_loading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8072);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks__WEBPACK_IMPORTED_MODULE_0__]);
_hooks__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





// import { useTranslation } from "react-i18next";
const useGomakeLogin = ()=>{
    // const { t } = useTranslation();
    const { callApi  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeAxios */ .S2)();
    const { navigate  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_0__/* .useGomakeRouter */ .VS)();
    const setLoadingState = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useSetRecoilState)(_store_loading__WEBPACK_IMPORTED_MODULE_2__/* .loadgingState */ .y);
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({});
    const [errors, setErrors] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        username: false,
        password: false
    });
    const changeState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)((key, value)=>{
        setState({
            ...state,
            [key]: value
        });
    }, [
        state
    ]);
    const onClickLogin = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(async ()=>{
        const result = await callApi("POST", "/v1/auth/login-customer", {
            userPrincipalName: state.username,
            password: state.password
        });
        console.log("result", result);
        if (result?.data?.data?.customer?.token) {
            (0,_services_storage_data__WEBPACK_IMPORTED_MODULE_1__/* .updateTokenStorage */ .Yr)(result?.data?.data?.customer?.token);
            navigate("/");
        }
    }, [
        state
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        console.log(state);
    }, [
        state
    ]);
    const inputs = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return [
            {
                name: "username",
                label: "login.username",
                type: "text",
                placeholder: "Username",
                required: true,
                key: "username"
            },
            {
                name: "password",
                label: "login.password",
                type: "password",
                placeholder: "Password",
                required: true,
                key: "password"
            }
        ];
    }, []);
    return {
        inputs,
        errors,
        changeState,
        onClickLogin
    };
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9085:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* reexport safe */ _machine_list__WEBPACK_IMPORTED_MODULE_0__.C)
/* harmony export */ });
/* harmony import */ var _machine_list__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3484);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_machine_list__WEBPACK_IMPORTED_MODULE_0__]);
_machine_list__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3484:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ MachineList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8125);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Menu__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9271);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _widgets_machine_list_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5528);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7987);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4845);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1412);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_7__, _hooks__WEBPACK_IMPORTED_MODULE_11__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_7__, _hooks__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const MachineList = ({})=>{
    const [anchorEl, setAnchorEl] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(null);
    const [filter, setFilter] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)();
    const open = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    const { classes  } = (0,_widgets_machine_list_style__WEBPACK_IMPORTED_MODULE_4__/* .useStyle */ .X)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const { getMachinesList , machines , setMachineChecked , checkAllMachines  } = (0,_hooks__WEBPACK_IMPORTED_MODULE_11__/* .useGomakeMachines */ .gB)();
    const handleFilterChange = (event)=>{
        setFilter(event.currentTarget.value);
    };
    const getMachines = ()=>{
        if (filter) {
            return machines.filter((machine)=>machine.name.toLowerCase().includes(filter.toLowerCase()));
        } else {
            return machines;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        getMachinesList();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
                style: classes.button,
                variant: "contained",
                onClick: handleClick,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: t("machines-list-widget.machinesList")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_8___default()), {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledMenu, {
                anchorEl: anchorEl,
                open: open,
                onClose: handleClose,
                MenuListProps: {
                    "aria-labelledby": "basic-button"
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.FormGroup, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: classes.searchInput,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_10__/* .GomakeTextInput */ .Jw, {
                                placeholder: "search machine",
                                value: filter,
                                onChange: handleFilterChange
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                            style: classes.machineName,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.FormControlLabel, {
                                label: t("dashboard-widget.all"),
                                control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Checkbox, {
                                    checked: getMachines().every((machine)=>machine.checked),
                                    onChange: ()=>{
                                        checkAllMachines();
                                    }
                                })
                            })
                        }),
                        getMachines().map((machine)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                                style: classes.machineName,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.FormControlLabel, {
                                    label: machine.name,
                                    control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Checkbox, {
                                        checked: machine.checked,
                                        onChange: ()=>{
                                            setMachineChecked(machine.id);
                                        }
                                    })
                                })
                            }, machine.id);
                        })
                    ]
                })
            })
        ]
    });
};
const StyledMenu = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_9__.styled)((props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Menu__WEBPACK_IMPORTED_MODULE_2___default()), {
        elevation: 0,
        anchorOrigin: {
            vertical: "bottom",
            horizontal: "right"
        },
        transformOrigin: {
            vertical: "top",
            horizontal: "right"
        },
        ...props
    }))(()=>({
        "& .MuiPaper-root": {
            borderRadius: 6,
            width: "250px",
            height: 500,
            boxShadow: "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
            "& .MuiMenu-list": {
                padding: "4px 0"
            },
            "& .MuiMenuItem-root": {
                fontSize: "12px",
                color: "#12133A",
                padding: 0
            },
            "& .MuiFormControlLabel-root": {
                margin: 0
            }
        }
    }));


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5528:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_font_family__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4680);
/* harmony import */ var _hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3254);



const useStyle = ()=>{
    const { theme , neutralColor , primaryColor  } = (0,_hooks_use_gomake_thme__WEBPACK_IMPORTED_MODULE_2__/* .useGomakeTheme */ .G)();
    const classes = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return {
            container: {},
            button: {
                backgroundColor: neutralColor(100),
                boxShadow: "0px 4px 90px rgba(135, 130, 130, 0.2)",
                borderRadius: "10px",
                color: primaryColor(700),
                width: "190px",
                height: "40px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(500, 12)
            },
            machineName: {
                ..._utils_font_family__WEBPACK_IMPORTED_MODULE_1__/* .FONT_FAMILY.Lexend */ .u.Lexend(500, 12)
            },
            searchInput: {
                maxWidth: "200px",
                margin: "5px"
            }
        };
    }, [
        theme
    ]);
    return {
        classes
    };
};



/***/ }),

/***/ 9721:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "u": () => (/* reexport */ WaitingAuth)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/widgets/waiting-auth/loading.json
var loading = __webpack_require__(5686);
var loading_namespaceObject = /*#__PURE__*/__webpack_require__.t(loading, 2);
// EXTERNAL MODULE: ./src/hooks/use-gomake-thme.ts
var use_gomake_thme = __webpack_require__(3254);
// EXTERNAL MODULE: ./src/utils/font-family.ts
var font_family = __webpack_require__(4680);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/widgets/waiting-auth/style.ts



const useStyle = ()=>{
    const { theme , primaryColor  } = (0,use_gomake_thme/* useGomakeTheme */.G)();
    const clasess = (0,external_react_.useMemo)(()=>{
        return {
            container: {
                backgroundColor: primaryColor(100),
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                minHeight: "100vh",
                ...font_family/* FONT_FAMILY.Lexend */.u.Lexend(600, 16)
            }
        };
    }, [
        theme
    ]);
    return {
        clasess
    };
};


;// CONCATENATED MODULE: ./src/widgets/waiting-auth/waiting-auth.tsx



const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: loading_namespaceObject,
    rendererSettings: {
        preserveAspectRatio: "xMidYMid slice"
    }
};
const WaitingAuth = ()=>{
    const { clasess  } = useStyle();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: clasess.container
    });
};


;// CONCATENATED MODULE: ./src/widgets/waiting-auth/index.ts



/***/ }),

/***/ 2746:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* reexport safe */ _widget_name__WEBPACK_IMPORTED_MODULE_0__.h)
/* harmony export */ });
/* harmony import */ var _widget_name__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9315);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_widget_name__WEBPACK_IMPORTED_MODULE_0__]);
_widget_name__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2017:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useStyle = ()=>{
    const clasess = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return {
            container: {
            }
        };
    }, []);
    return {
        clasess
    };
};



/***/ }),

/***/ 9315:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ WidgetName)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1412);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2021);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2017);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_2__]);
i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const WidgetName = ()=>{
    const { clasess  } = (0,_style__WEBPACK_IMPORTED_MODULE_3__/* .useStyle */ .X)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: clasess.container,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: ()=>(0,i18next__WEBPACK_IMPORTED_MODULE_2__.changeLanguage)("ar"),
                        children: "Arabic"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: ()=>(0,i18next__WEBPACK_IMPORTED_MODULE_2__.changeLanguage)("en"),
                        children: "English"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: ()=>(0,i18next__WEBPACK_IMPORTED_MODULE_2__.changeLanguage)("he"),
                        children: "Hebrow"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .ComponentName */ .yL, {
                text: "Hey mohanad"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .ComponentName */ .yL, {
                text: "Hey faraj"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_1__/* .ComponentName */ .yL, {
                text: "Hey faraj"
            })
        ]
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5686:
/***/ ((module) => {

module.exports = JSON.parse('{"nm":"Loading ","ddd":0,"h":500,"w":500,"meta":{"g":"LottieFiles AE 1.0.0"},"layers":[{"ty":4,"nm":"Rectangle_1","sr":1,"st":0,"op":90.0000036657751,"ip":0,"hd":false,"ddd":0,"bm":0,"hasMask":false,"ao":0,"ks":{"a":{"a":0,"k":[-125,-107,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6},"sk":{"a":0,"k":0},"p":{"a":1,"k":[{"o":{"x":0.333,"y":0},"i":{"x":0.667,"y":1},"s":[250,157.375,0],"t":0,"ti":[0.031,-0.052,0],"to":[15.448,15.438,0]},{"o":{"x":0.333,"y":0},"i":{"x":0.667,"y":1},"s":[342.688,250,0],"t":15,"ti":[15.448,-15.427,0],"to":[-0.059,0.098,0]},{"s":[250,342.563,0],"t":30.0000012219251}],"ix":2},"r":{"a":0,"k":45,"ix":10},"sa":{"a":0,"k":0},"o":{"a":0,"k":100,"ix":11}},"ef":[],"shapes":[{"ty":"gr","bm":0,"hd":false,"mn":"ADBE Vector Group","nm":"Rectangle 1","ix":1,"cix":2,"np":3,"it":[{"ty":"sh","bm":0,"hd":false,"mn":"ADBE Vector Shape - Group","nm":"Path 1","ix":1,"d":1,"ks":{"a":0,"k":{"c":true,"i":[[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0]],"v":[[57,-57],[57,57],[-57,57],[-57,-57]]},"ix":2}},{"ty":"st","bm":0,"hd":false,"mn":"ADBE Vector Graphic - Stroke","nm":"Stroke 1","lc":1,"lj":1,"ml":4,"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":0,"ix":5},"c":{"a":0,"k":[1,1,1],"ix":3}},{"ty":"fl","bm":0,"hd":false,"mn":"ADBE Vector Graphic - Fill","nm":"Fill 1","c":{"a":0,"k":[0.1804,0.1882,0.5725],"ix":4},"r":1,"o":{"a":0,"k":100,"ix":5}},{"ty":"tr","a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"sk":{"a":0,"k":0,"ix":4},"p":{"a":0,"k":[-125,-107],"ix":2},"r":{"a":0,"k":0,"ix":6},"sa":{"a":0,"k":0,"ix":5},"o":{"a":0,"k":100,"ix":7}}]}],"ind":1},{"ty":4,"nm":"Rectangle_2","sr":1,"st":0,"op":90.0000036657751,"ip":0,"hd":false,"ddd":0,"bm":0,"hasMask":false,"ao":0,"ks":{"a":{"a":0,"k":[-125,-107,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6},"sk":{"a":0,"k":0},"p":{"a":1,"k":[{"o":{"x":0.333,"y":0},"i":{"x":0.667,"y":1},"s":[342.688,250,0],"t":0,"ti":[-0.01,0,0],"to":[0.052,-0.073,0]},{"o":{"x":0.333,"y":0},"i":{"x":0.667,"y":1},"s":[250,342.563,0],"t":15,"ti":[0.198,-0.073,0],"to":[0.104,0,0]},{"s":[157.313,250,0],"t":30.0000012219251}],"ix":2},"r":{"a":0,"k":45,"ix":10},"sa":{"a":0,"k":0},"o":{"a":0,"k":100,"ix":11}},"ef":[],"shapes":[{"ty":"gr","bm":0,"hd":false,"mn":"ADBE Vector Group","nm":"Rectangle 1","ix":1,"cix":2,"np":3,"it":[{"ty":"sh","bm":0,"hd":false,"mn":"ADBE Vector Shape - Group","nm":"Path 1","ix":1,"d":1,"ks":{"a":0,"k":{"c":true,"i":[[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0]],"v":[[57,-57],[57,57],[-57,57],[-57,-57]]},"ix":2}},{"ty":"st","bm":0,"hd":false,"mn":"ADBE Vector Graphic - Stroke","nm":"Stroke 1","lc":1,"lj":1,"ml":4,"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":0,"ix":5},"c":{"a":0,"k":[1,1,1],"ix":3}},{"ty":"fl","bm":0,"hd":false,"mn":"ADBE Vector Graphic - Fill","nm":"Fill 1","c":{"a":0,"k":[0.9294,0.0078,0.549],"ix":4},"r":1,"o":{"a":0,"k":100,"ix":5}},{"ty":"tr","a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"sk":{"a":0,"k":0,"ix":4},"p":{"a":0,"k":[-125,-107],"ix":2},"r":{"a":0,"k":0,"ix":6},"sa":{"a":0,"k":0,"ix":5},"o":{"a":0,"k":100,"ix":7}}]}],"ind":2},{"ty":4,"nm":"Rectangle_3","sr":1,"st":0,"op":90.0000036657751,"ip":0,"hd":false,"ddd":0,"bm":0,"hasMask":false,"ao":0,"ks":{"a":{"a":0,"k":[-125,-107,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6},"sk":{"a":0,"k":0},"p":{"a":1,"k":[{"o":{"x":0.333,"y":0},"i":{"x":0.667,"y":1},"s":[250,342.563,0],"t":0,"ti":[0.04,-0.012,0],"to":[0.052,0.198,0]},{"o":{"x":0.333,"y":0},"i":{"x":0.667,"y":1},"s":[157.313,250,0],"t":15,"ti":[0.052,-0.563,0],"to":[-0.492,0.145,0]},{"s":[250,157.375,0],"t":30.0000012219251}],"ix":2},"r":{"a":0,"k":45,"ix":10},"sa":{"a":0,"k":0},"o":{"a":0,"k":100,"ix":11}},"ef":[],"shapes":[{"ty":"gr","bm":0,"hd":false,"mn":"ADBE Vector Group","nm":"Rectangle 1","ix":1,"cix":2,"np":3,"it":[{"ty":"sh","bm":0,"hd":false,"mn":"ADBE Vector Shape - Group","nm":"Path 1","ix":1,"d":1,"ks":{"a":0,"k":{"c":true,"i":[[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0]],"v":[[57,-57],[57,57],[-57,57],[-57,-57]]},"ix":2}},{"ty":"st","bm":0,"hd":false,"mn":"ADBE Vector Graphic - Stroke","nm":"Stroke 1","lc":1,"lj":1,"ml":4,"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":0,"ix":5},"c":{"a":0,"k":[1,1,1],"ix":3}},{"ty":"fl","bm":0,"hd":false,"mn":"ADBE Vector Graphic - Fill","nm":"Fill 1","c":{"a":0,"k":[0.1804,0.1882,0.5725],"ix":4},"r":1,"o":{"a":0,"k":100,"ix":5}},{"ty":"tr","a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"sk":{"a":0,"k":0,"ix":4},"p":{"a":0,"k":[-125,-107],"ix":2},"r":{"a":0,"k":0,"ix":6},"sa":{"a":0,"k":0,"ix":5},"o":{"a":0,"k":100,"ix":7}}]}],"ind":3},{"ty":4,"nm":"Rectangle_4","sr":1,"st":0,"op":90.0000036657751,"ip":0,"hd":false,"ddd":0,"bm":0,"hasMask":false,"ao":0,"ks":{"a":{"a":0,"k":[-125,-107,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6},"sk":{"a":0,"k":0},"p":{"a":1,"k":[{"o":{"x":0.333,"y":0},"i":{"x":0.667,"y":1},"s":[157.313,250,0],"t":0,"ti":[-0.079,0.525,0],"to":[15.448,-15.438,0]},{"o":{"x":0.333,"y":0},"i":{"x":0.667,"y":1},"s":[250,157.375,0],"t":15,"ti":[-15.448,-15.438,0],"to":[0.019,-0.125,0]},{"s":[342.688,250,0],"t":30.0000012219251}],"ix":2},"r":{"a":0,"k":45,"ix":10},"sa":{"a":0,"k":0},"o":{"a":0,"k":100,"ix":11}},"ef":[],"shapes":[{"ty":"gr","bm":0,"hd":false,"mn":"ADBE Vector Group","nm":"Rectangle 1","ix":1,"cix":2,"np":3,"it":[{"ty":"sh","bm":0,"hd":false,"mn":"ADBE Vector Shape - Group","nm":"Path 1","ix":1,"d":1,"ks":{"a":0,"k":{"c":true,"i":[[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0]],"v":[[57,-57],[57,57],[-57,57],[-57,-57]]},"ix":2}},{"ty":"st","bm":0,"hd":false,"mn":"ADBE Vector Graphic - Stroke","nm":"Stroke 1","lc":1,"lj":1,"ml":4,"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":0,"ix":5},"c":{"a":0,"k":[1,1,1],"ix":3}},{"ty":"fl","bm":0,"hd":false,"mn":"ADBE Vector Graphic - Fill","nm":"Fill 1","c":{"a":0,"k":[0.9294,0.0078,0.549],"ix":4},"r":1,"o":{"a":0,"k":100,"ix":5}},{"ty":"tr","a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"sk":{"a":0,"k":0,"ix":4},"p":{"a":0,"k":[-125,-107],"ix":2},"r":{"a":0,"k":0,"ix":6},"sa":{"a":0,"k":0,"ix":5},"o":{"a":0,"k":100,"ix":7}}]}],"ind":4}],"v":"4.8.0","fr":29.9700012207031,"op":31.0000012626559,"ip":0,"assets":[]}');

/***/ })

};
;